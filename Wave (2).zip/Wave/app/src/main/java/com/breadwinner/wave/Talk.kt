package com.breadwinner.wave

import android.content.Context
import android.content.res.AssetManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Wave's voice: Kokoro, a natural offline voice. Falls back to Android's voice if Kokoro isn't loaded. */
object Speaker {
    @Volatile private var tts: OfflineTts? = null
    private val known = HashSet<String>(200000)
    private val q = Executors.newSingleThreadExecutor()
    @Volatile var speaking = false
    @Volatile var quietUntil = 0L
    @Volatile private var stopNow = false

    val ready: Boolean get() = tts != null

    /** The voices in this model, and their numbers inside it. */
    val voices = listOf(
        "George" to 9, "Lewis" to 10, "Emma" to 7, "Isabella" to 8,
        "Adam" to 5, "Michael" to 6, "Bella" to 1, "Sarah" to 3
    )

    /** True while Wave is talking or just finished, so the ears don't hear Wave's own voice. */
    fun busy(): Boolean = speaking || System.currentTimeMillis() < quietUntil

    private fun exists(am: AssetManager?, path: String): Boolean = Engines.has(path)

    fun load(c: Context): String? {
        if (tts != null) return null
        val am: AssetManager? = null
        if (!exists(am, "tts/model.onnx")) return "The voice is missing from this build."
        return try {
            Buddy.status = "Loading the voice..."
            loadWords(am)
            tts = OfflineTts(
                am, OfflineTtsConfig(
                    model = OfflineTtsModelConfig(
                        kokoro = OfflineTtsKokoroModelConfig(
                            model = Engines.path("tts/model.onnx"),
                            voices = Engines.path("tts/voices.bin"),
                            tokens = Engines.path("tts/tokens.txt"),
                            lexicon = Engines.path("tts/lexicon-en-us.txt"),
                        ),
                        numThreads = 3,
                    ),
                    maxNumSentences = 1,
                )
            )
            null
        } catch (e: Throwable) {
            tts = null
            "Couldn't load the voice: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    private fun loadWords(am: AssetManager?) {
        if (known.isNotEmpty()) return
        try {
            java.io.File(Engines.path("tts/lexicon-en-us.txt")).bufferedReader().useLines { lines ->
                for (l in lines) {
                    if (l.startsWith("#")) continue
                    val i = l.indexOf(" ||")
                    if (i > 0) known.add(l.substring(0, i).lowercase())
                }
            }
        } catch (e: Exception) { }
    }

    fun stop() { stopNow = true }

    fun say(text: String) {
        val t = prepare(text)
        if (t.isBlank()) return
        stopNow = false
        speaking = true
        q.execute { speakNow(t) }
    }

    private fun speakNow(text: String) {
        val t = tts
        if (t == null) { speaking = false; return }
        var track: AudioTrack? = null
        try {
            val rate = t.sampleRate()
            val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
            val tr = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, rate))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = tr
            Sound.duck()
            tr.play()
            val sid = Store.i("voice", 9)
            val speed = Store.f("vspeed", 1.0f)
            var total = 0
            t.generateWithCallback(text, sid, speed) { samples ->
                if (!stopNow) {
                    tr.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
                    total += samples.size
                }
                if (stopNow) 0 else 1
            }
            // let the last bit of sound play out
            Thread.sleep(350)
        } catch (e: Throwable) {
        } finally {
            try { track?.stop() } catch (e: Throwable) { }
            try { track?.release() } catch (e: Throwable) { }
            speaking = false
            quietUntil = System.currentTimeMillis() + 300
            Sound.unduckSoon(600)
        }
    }

    /** Turns numbers into words and splits words the voice doesn't know ("WhatsApp" becomes "whats app"). */
    fun prepare(text: String): String {
        val out = StringBuilder()
        val tok = Regex("[A-Za-z']+|[0-9]+|[^A-Za-z0-9']+")
        for (m in tok.findAll(text)) {
            val w = m.value
            when {
                w[0].isDigit() -> out.append(Numbers.say(w.toLongOrNull() ?: 0L))
                w[0].isLetter() || w[0] == '\'' -> out.append(fixWord(w))
                else -> out.append(w)
            }
        }
        return out.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun fixWord(w: String): String {
        if (known.isEmpty()) return w
        val lw = w.lowercase()
        if (known.contains(lw)) return w
        // camel case: "WhatsApp" -> "Whats App"
        val camel = w.replace(Regex("([a-z])([A-Z])"), "$1 $2")
        if (camel != w && camel.split(" ").all { known.contains(it.lowercase()) }) return camel
        // the fewest known pieces that make up the word
        val n = lw.length
        val best = arrayOfNulls<List<String>>(n + 1)
        best[0] = emptyList()
        for (i in 1..n) {
            for (j in maxOf(0, i - 14) until i) {
                val prev = best[j] ?: continue
                val piece = lw.substring(j, i)
                if (piece.length < 2 && piece != "a") continue
                if (!known.contains(piece)) continue
                val cand = prev + piece
                val cur = best[i]
                if (cur == null || cand.size < cur.size) best[i] = cand
            }
        }
        val split = best[n]
        if (split != null && split.size <= 3) return split.joinToString(" ")
        // spell it out
        return lw.filter { it.isLetter() }.toCharArray().joinToString(" ")
    }
}

/** Numbers as words, for the voice. */
object Numbers {
    private val ones = listOf(
        "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
        "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"
    )
    private val tens = listOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")

    fun say(n: Long): String {
        if (n < 0) return "minus " + say(-n)
        if (n < 20) return ones[n.toInt()]
        if (n < 100) return tens[(n / 10).toInt()] + if (n % 10 != 0L) " " + ones[(n % 10).toInt()] else ""
        if (n < 1000) return ones[(n / 100).toInt()] + " hundred" + if (n % 100 != 0L) " and " + say(n % 100) else ""
        if (n < 1_000_000) return say(n / 1000) + " thousand" + if (n % 1000 != 0L) " " + say(n % 1000) else ""
        if (n < 1_000_000_000) return say(n / 1_000_000) + " million" + if (n % 1_000_000 != 0L) " " + say(n % 1_000_000) else ""
        return n.toString().toCharArray().joinToString(" ") { ones[it - '0'] }
    }

    fun ordinal(n: Int): String {
        val special = mapOf(
            1 to "first", 2 to "second", 3 to "third", 5 to "fifth", 8 to "eighth", 9 to "ninth", 12 to "twelfth",
            20 to "twentieth", 30 to "thirtieth"
        )
        special[n]?.let { return it }
        if (n > 20 && n % 10 != 0) return tens[n / 10] + " " + ordinal(n % 10)
        return say(n.toLong()) + "th"
    }
}

/** Small talk: greetings and questions Wave answers itself, plus the replies you teach it. */
object Chat {
    class Reply(val text: String, val sleep: Boolean = false)

    val mine = mutableStateListOf<Pair<String, String>>()   // when I say -> reply
    private var loaded = false

    private fun load() {
        if (loaded) return
        loaded = true
        try {
            val a = JSONArray(Store.s("talk", "[]"))
            for (i in 0 until a.length()) {
                val p = a.getJSONArray(i)
                mine.add(p.getString(0) to p.getString(1))
            }
        } catch (e: Exception) { }
    }

    private fun save() {
        val a = JSONArray()
        for ((k, v) in mine) a.put(JSONArray().put(k).put(v))
        Store.put("talk", a.toString())
    }

    fun add(said: String, reply: String) {
        load()
        val k = Norm.clean(said)
        if (k.isBlank() || reply.isBlank()) return
        mine.removeAll { it.first == k }
        mine.add(k to reply.trim())
        save()
    }

    fun remove(p: Pair<String, String>) {
        load()
        mine.remove(p)
        save()
    }

    fun all(): List<Pair<String, String>> { load(); return mine.toList() }

    /** What to call you. Mixed up a little so it doesn't get old. */
    private fun name(): String {
        val n = Store.s("callme", "BreadWinner").trim()
        if (n.isEmpty()) return "boss"
        return if (Math.random() < 0.7) n else listOf("boss", "chief", "my friend").random()
    }

    private fun pick(vararg options: String): String = options.random().replace("{n}", name())

    private fun hour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    private fun partOfDay(): String = when (hour()) {
        in 5..11 -> "morning"
        in 12..16 -> "afternoon"
        in 17..21 -> "evening"
        else -> "night"
    }

    fun timeWords(): String {
        val c = Calendar.getInstance()
        val h24 = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val h = if (h24 % 12 == 0) 12 else h24 % 12
        val ampm = if (h24 < 12) "in the morning" else if (h24 < 17) "in the afternoon" else if (h24 < 21) "in the evening" else "at night"
        val mins = when {
            m == 0 -> "o'clock"
            m < 10 -> "oh " + Numbers.say(m.toLong())
            else -> Numbers.say(m.toLong())
        }
        return "It's " + Numbers.say(h.toLong()) + " " + mins + " " + ampm + "."
    }

    fun dateWords(): String {
        val c = Calendar.getInstance()
        val day = SimpleDateFormat("EEEE", Locale.ENGLISH).format(Date())
        val month = SimpleDateFormat("MMMM", Locale.ENGLISH).format(Date())
        return "Today is " + day + ", the " + Numbers.ordinal(c.get(Calendar.DAY_OF_MONTH)) + " of " + month + "."
    }

    // ---- the conversation file (assets/talk/convos.json)

    private class Intent(val id: String, val replies: List<String>, val follow: Map<String, List<String>>, val puns: Boolean, val sleep: Boolean)

    private var intents: List<Intent> = emptyList()
    private var phrasings: HashMap<String, Int> = HashMap()
    private var base: List<Pair<String, Int>> = emptyList()
    private var punLines: List<String> = emptyList()
    private var keywords: Map<String, Int> = emptyMap()
    private var followPats: Map<String, Set<String>> = emptyMap()
    private var followGeneric: Map<String, List<String>> = emptyMap()
    @Volatile private var fileLoaded = false

    private var lastIntent = -1
    private var lastAt = 0L
    private val lastReply = HashMap<Int, String>()

    private val fillers = listOf("hey ", "yo ", "so ", "um ", "uh ", "okay ", "ok ", "hmm ", "well ", "bro ", "wave ", "hey wave ",
        "but ", "like ", "and ", "poseidon ", "hey poseidon ", "buddy ", "hey buddy ")
    private val tails = listOf(" wave", " buddy", " bro", " please", " man", " lol", " though", " tho", " poseidon", " my guy", " fam", " mate", " haha")

    /** Reads the conversation file once, in the background. */
    fun init(c: android.content.Context) {
        if (fileLoaded) return
        val app = c.applicationContext
        Thread {
            try {
                val txt = app.assets.open("talk/convos.json").bufferedReader().use { it.readText() }
                val o = org.json.JSONObject(txt)
                val ia = o.getJSONArray("intents")
                val list = ArrayList<Intent>(ia.length())
                for (i in 0 until ia.length()) {
                    val x = ia.getJSONObject(i)
                    val r = x.getJSONArray("r")
                    val reps = List(r.length()) { r.getString(it) }
                    val f = HashMap<String, List<String>>()
                    val fo = x.optJSONObject("f")
                    if (fo != null) for (k in fo.keys()) { val arr = fo.getJSONArray(k); f[k] = List(arr.length()) { arr.getString(it) } }
                    list.add(Intent(x.getString("id"), reps, f, x.optInt("p", 1) == 1, x.optInt("s", 0) == 1))
                }
                val po = o.getJSONObject("pats")
                val map = HashMap<String, Int>(po.length() * 2)
                for (k in po.keys()) map[k] = po.getInt(k)
                val ba = o.getJSONArray("base")
                val bl = ArrayList<Pair<String, Int>>(ba.length())
                for (i in 0 until ba.length()) { val e = ba.getJSONArray(i); bl.add(e.getString(0) to e.getInt(1)) }
                val kwo = o.optJSONObject("kw")
                val kwm = HashMap<String, Int>()
                if (kwo != null) for (k in kwo.keys()) kwm[k] = kwo.getInt(k)
                keywords = kwm
                val pa = o.getJSONArray("puns")
                val fp = o.getJSONObject("follow")
                val fpm = HashMap<String, Set<String>>()
                for (k in fp.keys()) { val arr = fp.getJSONArray(k); fpm[k] = (0 until arr.length()).map { arr.getString(it) }.toSet() }
                val fg = o.getJSONObject("followGeneric")
                val fgm = HashMap<String, List<String>>()
                for (k in fg.keys()) { val arr = fg.getJSONArray(k); fgm[k] = List(arr.length()) { arr.getString(it) } }
                intents = list; phrasings = map; base = bl
                punLines = List(pa.length()) { pa.getString(it) }
                followPats = fpm; followGeneric = fgm
                fileLoaded = true
            } catch (e: Exception) { }
        }.start()
    }

    /** Takes "yo wave how are you bro" down to "how are you". */
    private fun trim(t: String): String {
        var s = t
        var changed = true
        while (changed) {
            changed = false
            for (f in fillers) if (s.startsWith(f) && s.length > f.length + 1) { s = s.removePrefix(f); changed = true }
            for (x in tails) if (s.endsWith(x) && s.length > x.length + 1) { s = s.removeSuffix(x); changed = true }
        }
        return s.trim()
    }

    private fun findIntent(t: String): Int {
        phrasings[t]?.let { return it }
        val s = trim(t)
        phrasings[s]?.let { return it }
        if (s.length < 5) return -1
        var best = -1
        var bestSim = 0.86f
        for ((p, i) in base) {
            if (kotlin.math.abs(p.length - s.length) > 6) continue
            val v = Norm.sim(s, p)
            if (v >= bestSim) { bestSim = v; best = i }
        }
        return best
    }

    /** How often Wave slips in a wave pun: Off, Rare or Often (Voice page). */
    private fun punChance(): Double = when (Store.s("attitude", "rare")) { "off" -> 0.0; "often" -> 0.35; else -> 0.12 }

    private fun fill(r: String): String {
        if (r.startsWith("@greet:")) return greet(r.removePrefix("@greet:"))
        var x = r
        if (x.contains("{time}")) x = x.replace("{time}", timeWords())
        if (x.contains("{date}")) x = x.replace("{date}", dateWords())
        if (x.contains("{coin}")) x = x.replace("{coin}", if (Math.random() < 0.5) "Heads." else "Tails.")
        if (x.contains("{dice}")) x = x.replace("{dice}", "You rolled a " + Numbers.say((1..6).random().toLong()) + ".")
        if (x.contains("{rand}")) x = x.replace("{rand}", Numbers.say((1..100).random().toLong()) + ".")
        return x.replace("{n}", name())
    }

    private fun choose(idx: Int, from: List<String>): String {
        if (from.isEmpty()) return ""
        val last = lastReply[idx]
        var r = from.random()
        if (from.size > 1) { var tries = 0; while (r == last && tries < 4) { r = from.random(); tries++ } }
        lastReply[idx] = r
        return r
    }

    fun reply(raw: String): Reply? {
        load()
        var t = Norm.clean(raw)
        for (tail in listOf(" wave", " buddy", " please", " poseidon")) if (t.endsWith(tail)) t = t.removeSuffix(tail).trim()
        if (t.isEmpty()) return null
        val now = System.currentTimeMillis()

        // your own replies come first
        for ((k, v) in mine) if (t == k || (k.length >= 6 && Norm.sim(t, k) >= 0.86f)) return Reply(v.replace("{n}", name()))

        if (!fileLoaded) return null

        // a follow-up to what we just talked about: "why?", "really?", "and you?", "another one"
        if (lastIntent >= 0 && now - lastAt < 45000) {
            val s = trim(t)
            for ((kind, ps) in followPats) {
                if (!ps.contains(s)) continue
                val cur = intents[lastIntent]
                lastAt = now
                if (kind == "more") return Reply(fill(choose(lastIntent, cur.replies)))
                val own = cur.follow[kind]
                if (own != null && own.isNotEmpty()) return Reply(fill(own.random()))
                val gen = followGeneric[kind]
                if (gen != null && gen.isNotEmpty()) return Reply(fill(gen.random()))
            }
        }

        val idx = findIntent(t)
        if (idx < 0) return null
        val cur = intents[idx]
        lastIntent = idx
        lastAt = now
        var text = fill(choose(idx, cur.replies))
        if (cur.puns && punLines.isNotEmpty() && Math.random() < punChance()) text = text + " " + punLines.random()
        return Reply(text, sleep = cur.sleep)
    }

    /** Last try, only after a sentence turned out not to be a command: one telling word picks the topic. */
    fun loose(raw: String): Reply? {
        if (!fileLoaded) return null
        val words = Norm.clean(raw).split(" ")
        if (words.size > 8) return null
        for (w in words) {
            val idx = keywords[w] ?: continue
            val cur = intents[idx]
            lastIntent = idx
            lastAt = System.currentTimeMillis()
            return Reply(fill(choose(idx, cur.replies)), sleep = cur.sleep)
        }
        return null
    }

    private fun greet(said: String): String {
        val now = partOfDay()
        return if (now == said || (now == "night" && said == "evening")) pick("Good $said, {n}.", "Good $said, {n}. What's the plan?")
        else pick("Good $now actually, {n}. But good $said to you too.", "Ha, it's already $now, {n}.")
    }
}

// ---- screens

@Composable
fun TalkPage(back: () -> Unit) {
    var said by remember { mutableStateOf("") }
    var rep by remember { mutableStateOf("") }
    Page {
        Header("Small talk", "What I say back", back)
        Glass {
            Tx("Teach me a reply", 16)
            Tx("Say \"hey Wave\" then your words, and I'll answer with this. Use {n} for your name.", 13, Mute, FontWeight.Normal)
            Spacer(Modifier.height(10.dp))
            TextBox(said, "When I say… (wassup)") { said = it }
            Spacer(Modifier.height(8.dp))
            TextBox(rep, "Reply with… (Chilling, {n}. You?)") { rep = it }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Save reply", filled = true, enabled = said.isNotBlank() && rep.isNotBlank()) {
                    Chat.add(said, rep); said = ""; rep = ""
                }
                Btn("Hear it", enabled = rep.isNotBlank()) { Voice.say(rep.replace("{n}", Store.s("callme", "BreadWinner"))) }
            }
        }
        Glass {
            Tx("Your replies", 16)
            Spacer(Modifier.height(4.dp))
            val list = Chat.all()
            if (list.isEmpty()) Tx("None yet.", 13, Mute, FontWeight.Normal)
            for (p in list) {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Tx("“" + p.first + "”", 14)
                        Tx(p.second, 13, Mute, FontWeight.Normal)
                    }
                    Btn("✕") { Chat.remove(p) }
                }
            }
        }
        Glass {
            Tx("Already built in", 16)
            Tx("About 60 topics and over a thousand replies. A few to try:", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(4.dp))
            for (l in listOf(
                "Hello, hi, hey", "Good morning, afternoon, evening, good night", "How are you?", "Thank you",
                "Who are you?", "What time is it? What's the date?", "Are you there?", "Tell me a joke", "Fun fact", "I'm bored",
                "Motivate me", "Flip a coin", "Are you better than Siri?", "Then: why? really? another one"
            )) Tx(l, 13, Mute, FontWeight.Normal, modifier = Modifier.padding(vertical = 2.dp))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoicePage(back: () -> Unit) {
    var name by remember { mutableStateOf(Store.s("callme", "BreadWinner")) }
    var keyIn by remember { mutableStateOf("") }
    var needKey by remember { mutableStateOf(false) }
    val savedKey = Store.s("gemkey", "")
    Page {
        Header("Voice", "How Wave sounds", back)
        Glass {
            ToggleRow("Talk back", "Say replies out loud", Store.speak) { Store.put("speak", it) }
            if (!Speaker.ready) Tx("The natural voice isn't loaded yet, so I'll use the phone's own voice for now.", 12, Mute, FontWeight.Normal)
        }
        Glass {
            Tx("Voice", 16)
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((label, id) in Speaker.voices) {
                    Chip(label, Store.i("voice", 9) == id) {
                        Store.put("voice", id)
                        Voice.say("Hello, I'm Wave. This is how I sound.")
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            SliderRow("Speed", Store.f("vspeed", 1.0f), 0.7f..1.4f, "%.1fx".format(Locale.US, Store.f("vspeed", 1.0f))) { Store.put("vspeed", it) }
            Spacer(Modifier.height(6.dp))
            Btn("Test the voice", filled = true) { Voice.say(Chat.timeWords() + " All systems are running.") }
        }
        Glass {
            Tx("Wave attitude", 16)
            Tx("How often I slip in a wave pun.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            val att = listOf("off", "rare", "often")
            Seg(listOf("Off", "Rare", "Often"), att.indexOf(Store.s("attitude", "rare")).coerceAtLeast(0)) { Store.put("attitude", att[it]) }
        }
        Glass {
            Tx("Online or offline", 16)
            Tx("Offline keeps everything on this phone. Online lets Wave ask Gemini when it has no answer of its own.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            ToggleRow("Online mode", "Only the question's text is sent, never your voice. Off by default.", Store.b("online", false) && savedKey.isNotEmpty()) {
                if (it && savedKey.isEmpty()) needKey = true
                else { needKey = false; Store.put("online", it) }
            }
            if (needKey) Tx("Paste your Gemini key below and tap Save key first.", 12, Bad, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            Tx("Gemini key", 13)
            Spacer(Modifier.height(6.dp))
            TextBox(keyIn, "Paste your key here") { keyIn = it }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Save key", filled = true, enabled = keyIn.trim().length > 8) {
                    Store.put("gemkey", keyIn.trim()); keyIn = ""; needKey = false
                }
                if (savedKey.isNotEmpty()) Btn("Remove key") { Store.put("gemkey", ""); Store.put("online", false) }
            }
            Spacer(Modifier.height(6.dp))
            Tx(if (savedKey.isEmpty()) "No key saved yet. Get one free at aistudio.google.com." else "Key saved on this phone (ends in " + savedKey.takeLast(4) + ").", 12, Mute, FontWeight.Normal)
            Tx("Gemini's answers arrive in the next update. The switch and key are saved now. Wave never sends anything that looks like a code or PIN.", 12, Mute, FontWeight.Normal)
        }
        Glass {
            Tx("What should I call you?", 16)
            Spacer(Modifier.height(8.dp))
            TextBox(name, "BreadWinner") { name = it; Store.put("callme", it.trim()) }
        }
    }
}

@Composable
fun LatelyPage(back: () -> Unit) {
    Page {
        Header("Lately", "What I heard and did", back)
        Glass {
            if (Buddy.log.isEmpty()) Tx("Nothing yet. Say \"hey Wave\" and then a command.", 13, Mute, FontWeight.Normal)
            val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
            for (r in Buddy.log.toList()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                    Box(Modifier.padding(top = 6.dp).size(8.dp).clip(CircleShape).background(if (r.ok) Good else Bad))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx(r.did.ifEmpty { "Didn't catch that" }, 14, maxLines = 2)
                        Tx("“" + r.heard + "”", 12, Mute, FontWeight.Normal, maxLines = 2)
                        if (!r.ok && r.why.isNotEmpty()) Tx(r.why, 12, Bad, FontWeight.Normal)
                    }
                    Tx(fmt.format(Date(r.time)), 12, Mute, FontWeight.Normal)
                }
            }
        }
    }
}
