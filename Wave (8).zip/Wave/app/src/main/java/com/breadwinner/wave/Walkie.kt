package com.breadwinner.wave

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Walkie-talkie mode.
 * While it is on (or while "Always listening" is switched off) the microphone is fully closed.
 * It opens only while you hold the round button, and closes again when you let go.
 * Walkie mode ends by itself when the screen turns off, and Wave goes back to normal listening.
 */
object Walkie {
    /** True while walkie mode is switched on. Not saved: it ends with the screen anyway. */
    var on by mutableStateOf(false)

    fun alwaysListening(): Boolean = Store.b("alwayslisten", true)

    /** True when the mic stays shut until you hold the button. */
    fun micClosed(): Boolean = on || !alwaysListening()

    fun set(v: Boolean) {
        if (on == v) return
        on = v
        applyMic()
        MicService.refreshGate()
        Hands.inst?.setFabMode()
        if (v) Fx.words("Walkie-talkie", "Hold the round button to talk", 1800)
        else Fx.words(if (alwaysListening()) "Listening again" else "Walkie-talkie off", "", 1400)
    }

    /** Opens or closes the mic to match the settings. Call after any of them change. */
    fun applyMic() {
        if (!Buddy.micOn || !Ear.ready) return
        if (micClosed()) {
            if (!Brain.pttHeld) Ear.stop()
        } else {
            Ear.start()
        }
    }
}
