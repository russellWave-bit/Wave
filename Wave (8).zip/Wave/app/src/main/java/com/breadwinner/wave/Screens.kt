package com.breadwinner.wave

import android.Manifest
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

private val stepTypes = listOf(
    "OPEN_APP", "OPEN_URL", "WA_CHAT", "CALL", "SPEAKER", "TIMER", "ALARM", "TORCH", "VOLUME", "WAIT",
    "TAP_TEXT", "LONG_TEXT", "TAP_ID", "TAP_NUM", "TAP_XY", "TYPE", "SEND", "BACK", "HOME", "RECENTS",
    "SCROLL", "SWIPE", "NUMS_ON", "NUMS_OFF", "GRID_ON", "GRID_OFF", "READ_SCREEN", "WORDS"
)

private fun nice(t: String) = t.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }

@Composable
fun CommandsPage(back: () -> Unit, edit: (Command?) -> Unit) {
    Page {
        Header("Commands", "What you can say after \"" + Store.wake + "\"", back)
        Glass {
            Tx("Built in", 16)
            Tx("Switch whole groups on or off.", 12, Mute, FontWeight.Normal)
            for ((k, title, ex) in Parser.groups) {
                ToggleRow(title, ex, Store.b("bi_$k", true)) { Store.put("bi_$k", it) }
            }
        }
        Glass {
            Tx("Your commands", 16)
            Spacer(Modifier.height(4.dp))
            if (Store.cmds.isEmpty()) Tx("None yet.", 13, Mute, FontWeight.Normal)
            for (c in Store.cmds.toList()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { edit(c) }) {
                        Tx("\"" + c.phrase + "\"", 14)
                        Tx(c.steps.size.toString() + " steps" + if (c.ask) ", asks first" else "", 12, Mute, FontWeight.Normal)
                    }
                    androidx.compose.material3.Switch(checked = c.enabled, onCheckedChange = { on ->
                        val i = Store.cmds.indexOfFirst { it.id == c.id }
                        if (i >= 0) { Store.cmds[i] = c.copy(enabled = on); Store.saveCmds() }
                    })
                    Spacer(Modifier.width(6.dp))
                    Btn("Delete") { Store.cmds.removeAll { it.id == c.id }; Store.saveCmds() }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("New command", filled = true) { edit(null) }
                Btn("Add the starter pack") {
                    for (c in Starter.pack()) if (Store.cmds.none { it.phrase.equals(c.phrase, true) }) Store.cmds.add(c)
                    Store.saveCmds()
                }
            }
        }
        TeachCard(back)
        Glass {
            Tx("Tips", 15)
            Tx("Use {name} or {thing} in a phrase to leave a blank, like \"whatsapp call {name}\". The blank is filled with whatever you say there.", 12, Mute, FontWeight.Normal)
        }
    }
}

@Composable
private fun TeachCard(back: () -> Unit) {
    var phrase by remember { mutableStateOf("") }
    Glass {
        Tx("Teach by showing", 16)
        Tx("Type what you will say, press Record, then do the taps yourself. Say \"done\" or tap the round button when finished.", 12, Mute, FontWeight.Normal)
        Spacer(Modifier.height(8.dp))
        TextBox(phrase, "e.g. open my bank") { phrase = it }
        Spacer(Modifier.height(8.dp))
        Btn("Record", filled = true, enabled = phrase.isNotBlank()) {
            Brain.startRecording(Norm.clean(phrase))
            phrase = ""
            back()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditPage(cmd: Command?, done: () -> Unit) {
    var phrase by remember { mutableStateOf(cmd?.phrase ?: "") }
    var ask by remember { mutableStateOf(cmd?.ask ?: false) }
    val steps = remember { mutableStateListOf<Step>().also { if (cmd != null) it.addAll(cmd.steps) } }
    var pick by remember { mutableStateOf(-1) }
    val scope = rememberCoroutineScope()
    Page {
        Header(if (cmd == null) "New command" else "Edit command", "", done, "Close")
        Glass {
            Tx("What you say", 14)
            Spacer(Modifier.height(6.dp))
            TextBox(phrase, "whatsapp call {name}") { phrase = it }
            Tx("Leave blanks with {name}. Use the same name inside steps.", 12, Mute, FontWeight.Normal)
            ToggleRow("Ask me before running", "", ask) { ask = it }
        }
        steps.forEachIndexed { i, s ->
            Glass {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tx((i + 1).toString() + ". " + nice(s.type), 14, Coral, modifier = Modifier.weight(1f).clickable { pick = if (pick == i) -1 else i })
                    Btn("↑") { if (i > 0) { val t = steps[i]; steps[i] = steps[i - 1]; steps[i - 1] = t } }
                    Spacer(Modifier.width(6.dp))
                    Btn("↓") { if (i < steps.size - 1) { val t = steps[i]; steps[i] = steps[i + 1]; steps[i + 1] = t } }
                    Spacer(Modifier.width(6.dp))
                    Btn("✕") { steps.removeAt(i); pick = -1 }
                }
                if (pick == i) {
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (t in stepTypes) Chip(nice(t), t == s.type) { steps[i] = s.copy(type = t); pick = -1 }
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextBox(s.a, "Text, app, number or {name}") { steps[i] = s.copy(a = it) }
                Spacer(Modifier.height(6.dp))
                TextBox(if (s.n == 0) "" else s.n.toString(), "Number (waiting ms, tap number...)", numbers = true) {
                    steps[i] = s.copy(n = it.filter { c -> c.isDigit() }.take(6).toIntOrNull() ?: 0)
                }
            }
        }
        Btn("Add a step") { steps.add(Step("OPEN_APP")); pick = steps.size - 1 }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("Save", filled = true, enabled = phrase.isNotBlank() && steps.isNotEmpty()) {
                val c = Command(cmd?.id ?: Store.newId(), Norm.clean(phrase), steps.toList(), cmd?.enabled ?: true, ask)
                val i = Store.cmds.indexOfFirst { it.id == c.id }
                if (i >= 0) Store.cmds[i] = c else Store.cmds.add(c)
                Store.saveCmds()
                done()
            }
            Btn("Test run", enabled = steps.isNotEmpty()) {
                scope.launch { Runner.run(Plan(phrase.ifBlank { "test" }, steps.toList(), false, true, false)) }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LookPage(back: () -> Unit, calibrate: () -> Unit) {
    fun hit() { Hands.inst?.refresh() }
    Page {
        Header("Look and feel", "", back)
        Glass {
            Tx("Theme", 16)
            Spacer(Modifier.height(6.dp))
            val looks = listOf("studio", "night", "day")
            Seg(listOf("Poseidon", "Jarvis night", "Daylight"), looks.indexOf(Store.s("ui", "studio")).coerceAtLeast(0)) { Store.put("ui", looks[it]) }
            Spacer(Modifier.height(6.dp))
            Tx("Poseidon is the white and orange look that matches the octopus.", 12, Mute, FontWeight.Normal)
        }
        Glass {
            Tx("Floating words (shown when the eye is off)", 16)
            Spacer(Modifier.height(6.dp))
            val styles = listOf("drop", "float", "fade")
            Seg(listOf("Drop from camera", "Float up", "Fade"), styles.indexOf(Store.style).coerceAtLeast(0)) { Store.put("style", styles[it]) }
            SliderRow("Size", Store.textSize.toFloat(), 28f..110f, Store.textSize.toString()) { Store.put("tsize", it.toInt()) }
            SliderRow("Stays for", Store.holdMs.toFloat(), 500f..5000f, "%.1f s".format(java.util.Locale.US, Store.holdMs / 1000f)) { Store.put("hold", it.toInt()) }
            SliderRow("Height on screen", Store.posY, 0.15f..0.8f, (Store.posY * 100).toInt().toString() + "%") { Store.put("posy", it) }
            Tx("Font", 13)
            val fonts = listOf("rounded", "serif", "mono", "bold")
            Seg(listOf("Rounded", "Serif", "Mono", "Bold"), fonts.indexOf(Store.font).coerceAtLeast(0)) { Store.put("font", fonts[it]) }
            Spacer(Modifier.height(10.dp))
            Btn("Preview words", filled = true) { Fx.words("Hello " + Store.s("callme", "BreadWinner"), "This is how I will look", 2200) }
        }
        Glass {
            Tx("Colours", 16)
            Spacer(Modifier.height(4.dp))
            Tx("Tap a row, then slide along the spectrum. The second bar makes it darker or lighter.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            ColourPick("My words", "What I said, on the home screen", "c_words", Ink) { hit() }
            ColourPick("Wave's reply", "The home screen and the floating words", "c_reply", Coral) { hit() }
            ColourPick("Status", "The line under the Jarvis core", "c_status", Ink) { hit() }
            ColourPick("Glow", "The ring, the screen edges and the halo behind words", "c_glow", Coral) { hit() }
            Spacer(Modifier.height(10.dp))
            Btn("Preview words", filled = true) { Fx.words("Hello " + Store.s("callme", "BreadWinner"), "This is how I will look", 2200) }
        }
        Glass {
            Tx("Glow ring", 16)
            ToggleRow("Show the ring", "Around the camera hole", Store.ringOn) { Store.put("ring", it); hit() }
            ToggleRow("Faint glow when idle", "", Store.ringIdle) { Store.put("ringidle", it); hit() }
            ToggleRow("Glow along screen edges", "", Store.edgeGlow) { Store.put("edge", it); hit() }
            SliderRow("Thickness", Store.ringThick, 2f..14f, "%.0f".format(java.util.Locale.US, Store.ringThick)) { Store.put("rthick", it); hit() }
            SliderRow("Glow", Store.ringGlow, 0f..1f, (Store.ringGlow * 100).toInt().toString() + "%") { Store.put("rglow", it); hit() }
            SliderRow("Speed", Store.ringSpeed, 0.3f..3f, "%.1fx".format(java.util.Locale.US, Store.ringSpeed)) { Store.put("rspeed", it) }
            Tx("Preset colours (my own glow colour above wins)", 13)
            val themes = listOf("poseidon", "jarvis", "sea", "sunset", "lamp")
            Seg(listOf("Poseidon", "Jarvis", "Sea", "Sunset", "Lamp"), themes.indexOf(Store.theme).coerceAtLeast(0)) { Store.put("theme", themes[it]); hit() }
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Listening") { Fx.state(RingState.LISTEN) }
                Btn("Thinking") { Fx.state(RingState.THINK) }
                Btn("Done") { Fx.state(RingState.DONE) }
                Btn("Problem") { Fx.state(RingState.PROBLEM) }
                Btn("Calibrate", filled = true, onClick = calibrate)
            }
        }
        Glass {
            Tx("Round button", 16)
            ToggleRow("Show the floating button", "Hold to talk, drag to move, tap to wake or sleep", Store.fabOn) { Store.put("fab", it); hit() }
        }
    }
}

@Composable
fun CalibratePage(done: () -> Unit) {
    val ctx = LocalContext.current
    var size by remember { mutableStateOf(IntSize(1, 1)) }
    var cx by remember { mutableStateOf(Store.ringX) }
    var cy by remember { mutableStateOf(Store.ringY) }
    var r by remember { mutableStateOf(Store.ringR) }
    var thick by remember { mutableStateOf(Store.ringThick) }
    var msg by remember { mutableStateOf("Drag the ring onto your camera hole.") }
    Box(Modifier.fillMaxSize().background(Color(0xFF15111A)).onSizeChanged { size = it }
        .pointerInput(Unit) {
            detectDragGestures { ch, d ->
                ch.consume()
                cx = (cx + d.x / size.width).coerceIn(0f, 1f)
                cy = (cy + d.y / size.height).coerceIn(0f, 0.3f)
            }
        }) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            drawIntoCanvas { c ->
                RingPainter.draw(c.nativeCanvas, cx * w, cy * size.height, r * w, thick, Store.ringGlow, 0.1f, 1f, Fx.ringPal())
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)) {
            Glass {
                Tx(msg, 13, Mute, FontWeight.Normal)
                SliderRow("Ring size", r, 0.01f..0.06f, (r * 1000).toInt().toString()) { r = it }
                SliderRow("Thickness", thick, 2f..14f, "%.0f".format(java.util.Locale.US, thick)) { thick = it }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Find my camera") {
                        Store.put("rx", cx); Store.put("ry", cy); Store.put("rr", r)
                        val h = Hands.inst
                        if (h != null && h.findCamera()) {
                            cx = Store.ringX; cy = Store.ringY; r = Store.ringR
                            msg = "Found it. Fine-tune if you like."
                        } else msg = "Couldn't detect it. Turn on Wave Hands, or drag by hand."
                    }
                    Btn("Save", filled = true) {
                        Store.put("rx", cx); Store.put("ry", cy); Store.put("rr", r); Store.put("rthick", thick); Store.put("rcal", true)
                        Hands.inst?.refresh()
                        done()
                    }
                }
            }
        }
    }
}

@Composable
fun SafetyPage(back: () -> Unit) {
    Page {
        Header("Safety", "You are always in charge.", back)
        Glass {
            Tx("Ask before doing things", 16)
            Spacer(Modifier.height(6.dp))
            val modes = listOf("never", "risky", "always")
            Seg(listOf("Never ask", "Risky only", "Always ask"), modes.indexOf(Store.confirm).coerceAtLeast(1)) { Store.put("confirm", modes[it]) }
            Tx("Risky means calls, sends and anything that changes things.", 12, Mute, FontWeight.Normal)
        }
        Glass {
            Tx("What I may do", 16)
            ToggleRow("Open apps", "", Store.power("apps")) { Store.put("p_apps", it) }
            ToggleRow("Tap and scroll", "", Store.power("taps")) { Store.put("p_taps", it) }
            ToggleRow("Type text", "", Store.power("typing")) { Store.put("p_typing", it) }
            ToggleRow("Make calls", "", Store.power("calls")) { Store.put("p_calls", it) }
            ToggleRow("Phone settings", "Torch, volume, alarms", Store.power("system")) { Store.put("p_system", it) }
        }
        Glass {
            Tx("Secret phrase", 16)
            Tx("If set, risky things only happen after you say it.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            TextBox(Store.secret, "none") { Store.put("secret", Norm.clean(it)) }
        }
        Glass {
            ToggleRow("Little sounds", "A tone when I hear you", Store.cues) { Store.put("cues", it) }
            Tx("Country code for WhatsApp numbers", 13)
            Spacer(Modifier.height(6.dp))
            TextBox(Store.country, "263", numbers = true) { Store.put("country", it.filter { c -> c.isDigit() }.take(4)) }
        }
    }
}

@Composable
fun VocabPage(back: () -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    Page {
        Header("My words", "When I say X, I mean Y", back)
        Glass {
            TextBox(a, "When I say... (mum)") { a = it }
            Spacer(Modifier.height(8.dp))
            TextBox(b, "I mean... (Mum Mobile)") { b = it }
            Spacer(Modifier.height(8.dp))
            Btn("Add", filled = true, enabled = a.isNotBlank() && b.isNotBlank()) {
                Store.vocab.removeAll { it.first.equals(a.trim(), true) }
                Store.vocab.add(Norm.clean(a) to b.trim())
                Store.saveVocab()
                a = ""; b = ""
            }
        }
        Glass {
            if (Store.vocab.isEmpty()) Tx("Nothing yet.", 13, Mute, FontWeight.Normal)
            for (p in Store.vocab.toList()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("\"" + p.first + "\" → " + p.second, 14, modifier = Modifier.weight(1f))
                    Btn("✕") { Store.vocab.remove(p); Store.saveVocab() }
                }
            }
        }
    }
}

@Composable
fun TryPage(back: () -> Unit) {
    var t by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    Page {
        Header("Try it", "Type instead of speaking.", back)
        Glass {
            TextBox(t, "open whatsapp") { t = it }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("What would it do?", enabled = t.isNotBlank()) { out = Brain.explain(t) }
                Btn("Do it", filled = true, enabled = t.isNotBlank()) { Brain.typed(t) }
            }
            if (out.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Tx(out, 13, Mute, FontWeight.Normal)
            }
        }
        Glass {
            Tx("Things to say", 16)
            Spacer(Modifier.height(4.dp))
            for (l in Parser.helpLines) Tx(l, 12, Mute, FontWeight.Normal, modifier = Modifier.padding(vertical = 2.dp))
        }
    }
}

@Composable
fun SetupPage(finish: () -> Unit, calibrate: () -> Unit) {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var step by remember { mutableStateOf(0) }
    var bump by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        bump++
        if (has(ctx, Manifest.permission.RECORD_AUDIO) && !Buddy.micOn) MicService.start(ctx)
    }
    val mic = remember(tick, bump) { has(ctx, Manifest.permission.RECORD_AUDIO) }
    val acc = remember(tick, bump) { accOn(ctx) }
    val bat = remember(tick, bump) { batOk(ctx) }
    val titles = listOf("Hello", "Permissions", "Hands", "Battery", "Ears", "Wake word", "Your voice", "Done")
    Page {
        Header("Setup", "Step " + (step + 1) + " of " + titles.size + " \u2013 " + titles[step])
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in titles.indices) {
                Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(50)).background(if (i <= step) Coral else Peach))
            }
        }
        Glass {
            when (step) {
                0 -> {
                    JarvisCore(Modifier.fillMaxWidth().height(170.dp))
                    Tx("Hi " + Store.s("callme", "BreadWinner") + ". I'm Wave.", 20, weight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    Tx("Your hands-free helper. I listen for \"" + Store.wake + "\", then do what you ask. Everything I hear stays on this phone. This takes about three minutes.", 14, Mute, FontWeight.Normal)
                }
                1 -> {
                    Tx("Let me hear and call", 18, weight = FontWeight.Medium)
                    Tx("The microphone so I can hear you, contacts and phone so I can call people, and notifications so you can see I'm listening.", 14, Mute, FontWeight.Normal)
                    Spacer(Modifier.height(10.dp))
                    CheckRow("Microphone and the rest", mic, "Allow") { launcher.launch(wantedPerms()) }
                }
                2 -> {
                    Tx("Let me tap for you", 18, weight = FontWeight.Medium)
                    Tx("Wave Hands lets me tap, scroll and type in other apps.", 14, Mute, FontWeight.Normal)
                    Spacer(Modifier.height(8.dp))
                    Tx("1. Tap App info, then the three dots at the top right, then Allow restricted settings.", 14)
                    Spacer(Modifier.height(4.dp))
                    Tx("2. Tap Accessibility and switch on Wave Hands.", 14)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Btn("App info") { openAppInfo(ctx) }
                        Btn("Accessibility", filled = !acc) { openSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
                    }
                    Spacer(Modifier.height(8.dp))
                    CheckRow("Hands switched on", acc, "") { }
                }
                3 -> {
                    Tx("Keep me awake", 18, weight = FontWeight.Medium)
                    Tx("Set battery to Unrestricted so Android doesn't put me to sleep in the background.", 14, Mute, FontWeight.Normal)
                    Spacer(Modifier.height(10.dp))
                    CheckRow("Battery unrestricted", bat, "Fix") { askBattery(ctx) }
                }
                4 -> {
                    if (!Buddy.micOn && mic) { LaunchedEffect(Unit) { Buddy.sleeping = false; MicService.start(ctx) } }
                    JarvisCore(Modifier.fillMaxWidth().height(170.dp))
                    Tx(if (Buddy.micOn) "My ears are ready" else "Getting my ears ready", 18, weight = FontWeight.Medium)
                    Tx(Buddy.status, 14, Mute, FontWeight.Normal)
                    if (Buddy.modelError.isNotEmpty()) Tx(Buddy.modelError, 13, Bad, FontWeight.Normal)
                    if (!mic) Tx("Go back one step and allow the microphone first.", 13, Bad, FontWeight.Normal)
                }
                5 -> {
                    JarvisCore(Modifier.fillMaxWidth().height(170.dp))
                    Tx("Say \"" + Store.wake + "\" three times", 18, weight = FontWeight.Medium)
                    Tx("Pause between each one. The rings ripple when I hear it.", 14, Mute, FontWeight.Normal)
                    Spacer(Modifier.height(8.dp))
                    Tx(Buddy.wakeCount.coerceAtMost(3).toString() + " of 3", 22, if (Buddy.wakeCount >= 3) Good else Coral)
                    if (Buddy.wakeCount == 0) Tx("Not waking? You can make me easier to wake in Safety.", 12, Mute, FontWeight.Normal)
                }
                6 -> {
                    Tx("Only my voice (optional)", 18, weight = FontWeight.Medium)
                    Tx("Record your voice so I ignore other people and the TV. You can skip this and do it later.", 14, Mute, FontWeight.Normal)
                    Spacer(Modifier.height(10.dp))
                    EnrollBlock()
                }
                else -> {
                    JarvisCore(Modifier.fillMaxWidth().height(170.dp))
                    Tx("You're all set", 20, weight = FontWeight.Medium)
                    Tx("Say \"" + Store.wake + "\", then something like \"open WhatsApp\" or just \"hello\". Or hold the round button on the edge of your screen and talk.", 14, Mute, FontWeight.Normal)
                    Spacer(Modifier.height(10.dp))
                    Btn("Put the glow ring on my camera", onClick = calibrate)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (step > 0) Btn("Back") { step-- }
            if (step < titles.size - 1) Btn(if (step == 6 && !Voiceprint.enrolled) "Skip" else "Next", filled = true) { step++ }
            else Btn("Finish", filled = true, onClick = finish)
            if (step < titles.size - 1) Btn("Skip setup") { finish() }
        }
    }
}
