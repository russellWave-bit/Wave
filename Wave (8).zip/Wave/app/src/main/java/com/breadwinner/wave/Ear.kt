package com.breadwinner.wave

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.KeywordSpotter
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTransducerModelConfig
import com.k2fsa.sherpa.onnx.OnlineModelConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig
import com.k2fsa.sherpa.onnx.OfflineSpeechDenoiser
import com.k2fsa.sherpa.onnx.OfflineSpeechDenoiserConfig
import com.k2fsa.sherpa.onnx.OfflineSpeechDenoiserGtcrnModelConfig
import com.k2fsa.sherpa.onnx.OfflineSpeechDenoiserModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractor
import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractorConfig
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import java.util.concurrent.Executors

/**
 * The ears. Four small engines, all on the phone:
 *  - a wake-word spotter that only listens for "hey buddy"
 *  - a voice detector that cuts the sound into sentences
 *  - Parakeet, which turns a sentence into words
 *  - a voice-print engine, for "Only my voice"
 */
object Ear {
    private const val RATE = 16000
    private const val KWS_DIR = "kws"
    private const val KWS_ENC = "encoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx"
    private const val KWS_DEC = "decoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx"
    private const val KWS_JOIN = "joiner-epoch-12-avg-2-chunk-16-left-64.int8.onnx"

    @Volatile private var kws: KeywordSpotter? = null
    @Volatile private var kwsStream: OnlineStream? = null
    @Volatile private var vad: Vad? = null
    @Volatile private var asr: OfflineRecognizer? = null
    @Volatile private var spk: SpeakerEmbeddingExtractor? = null
    @Volatile private var clean: OfflineSpeechDenoiser? = null

    /** How loud the room is right now, 0 to 1. The Jarvis rings move with it. */
    @Volatile var level = 0f

    /** The background noise when nobody is talking. Used by the automatic noise cleaner. */
    @Volatile var noise = 0f

    /** True when the room is loud enough that the noise cleaner switches itself on. */
    fun noisy(): Boolean = noise > 0.015f

    // live captions: the sentence so far, re-read every so often while you talk
    private val live = ArrayList<FloatArray>()
    private var liveSamples = 0
    private var lastLive = 0L
    @Volatile private var liveBusy = false

    @Volatile var running = false
    @Volatile private var gen = 0
    @Volatile private var wakeUntil = 0L
    @Volatile private var kwsDirty = false
    private var thread: Thread? = null
    private val work = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    // the last two seconds of sound, for checking the voice on a wake word
    private val ring = FloatArray(RATE * 2)
    private var ringPos = 0
    private var ringFull = false

    val ready: Boolean get() = asr != null && vad != null
    val hasVoicePrint: Boolean get() = spk != null
    val hasWake: Boolean get() = kws != null

    /** The engines live in Wave's own storage, downloaded once (see Engines). */
    private fun exists(am: AssetManager?, path: String): Boolean = Engines.has(path)

    /** Loads the engines. Slow the first time (a few seconds), so call it off the main thread. */
    fun load(c: Context): String? {
        val am: AssetManager? = null
        Engines.prepare(c)
        try {
            if (vad == null) {
                if (!exists(am, "silero_vad.onnx")) return "The voice detector is missing from this build."
                vad = Vad(
                    am, VadModelConfig(
                        sileroVadModelConfig = SileroVadModelConfig(
                            model = Engines.path("silero_vad.onnx"),
                            threshold = 0.5f,
                            minSilenceDuration = 0.6f,
                            minSpeechDuration = 0.2f,
                            windowSize = 512,
                            maxSpeechDuration = 14f,
                        ),
                        sampleRate = RATE,
                        numThreads = 1,
                    )
                )
            }
            if (spk == null && exists(am, "speaker.onnx")) {
                try {
                    spk = SpeakerEmbeddingExtractor(am, SpeakerEmbeddingExtractorConfig(model = Engines.path("speaker.onnx"), numThreads = 2))
                } catch (e: Throwable) {
                    spk = null
                }
            }
            Voiceprint.modelPresent = spk != null
            if (clean == null && exists(am, "gtcrn.onnx")) {
                try {
                    clean = OfflineSpeechDenoiser(
                        am, OfflineSpeechDenoiserConfig(
                            model = OfflineSpeechDenoiserModelConfig(
                                gtcrn = OfflineSpeechDenoiserGtcrnModelConfig(model = Engines.path("gtcrn.onnx")),
                                numThreads = 1,
                            )
                        )
                    )
                } catch (e: Throwable) {
                    clean = null
                }
            }
            if (kws == null) buildKws(am)
            if (asr == null) {
                if (!exists(am, "asr/encoder.int8.onnx")) return "The speech engine is missing from this build."
                Buddy.status = "Loading the speech engine..."
                asr = OfflineRecognizer(
                    am, OfflineRecognizerConfig(
                        featConfig = FeatureConfig(sampleRate = RATE, featureDim = 80),
                        modelConfig = OfflineModelConfig(
                            transducer = OfflineTransducerModelConfig(
                                encoder = Engines.path("asr/encoder.int8.onnx"),
                                decoder = Engines.path("asr/decoder.int8.onnx"),
                                joiner = Engines.path("asr/joiner.int8.onnx"),
                            ),
                            tokens = Engines.path("asr/tokens.txt"),
                            modelType = "nemo_transducer",
                            numThreads = 4,
                        ),
                    )
                )
            }
        } catch (e: Throwable) {
            return "Couldn't start the engines: " + (e.message ?: e.javaClass.simpleName)
        }
        return null
    }

    private fun buildKws(am: AssetManager?) {
        if (!exists(am, "$KWS_DIR/$KWS_ENC")) { kws = null; return }
        try {
            val k = KeywordSpotter(
                am, KeywordSpotterConfig(
                    featConfig = FeatureConfig(sampleRate = RATE, featureDim = 80),
                    modelConfig = OnlineModelConfig(
                        transducer = OnlineTransducerModelConfig(
                            encoder = Engines.path("$KWS_DIR/$KWS_ENC"),
                            decoder = Engines.path("$KWS_DIR/$KWS_DEC"),
                            joiner = Engines.path("$KWS_DIR/$KWS_JOIN"),
                        ),
                        tokens = Engines.path("$KWS_DIR/tokens.txt"),
                        modelType = "zipformer2",
                        numThreads = 1,
                    ),
                    keywordsFile = Engines.path("$KWS_DIR/keywords.txt"),
                    keywordsScore = 1.8f,
                    keywordsThreshold = wakeThreshold(),
                )
            )
            kws = k
            kwsStream = k.createStream(extraKeywords())
        } catch (e: Throwable) {
            kws = null
            kwsStream = null
        }
    }

    /** Lower means it wakes more easily. The Wake sensitivity slider sets this. */
    private fun wakeThreshold(): Float = when (Store.s("wakesens", "normal")) {
        "easy" -> 0.12f
        "strict" -> 0.32f
        else -> 0.2f
    }

    private fun extraKeywords(): String =
        ""

    /** Call after the wake word or its sensitivity changes. */
    fun rebuildWake(c: Context) {
        kwsDirty = true
        Thread {
            val old = kws
            kws = null
            kwsStream = null
            try { old?.release() } catch (e: Throwable) { }
            buildKws(null)
            kwsDirty = false
        }.start()
    }

    fun start() {
        if (running) return
        running = true
        gen++
        val g = gen
        thread = Thread { loop(g) }.also { it.priority = Thread.MAX_PRIORITY; it.start() }
    }

    // ---- walkie-talkie: the mic opens only while the round button is held

    /** True while the mic is open just for a button hold. */
    @Volatile var holdMode = false
    @Volatile private var holdEnd = 0L

    /** The button went down: open the mic and listen for one sentence, no wake word needed. */
    fun holdStart() {
        if (!Walkie.micClosed()) return
        holdMode = true
        holdEnd = 0L
        if (!running) start()
    }

    /** The button came up: finish the sentence, then the mic closes itself. */
    fun holdStop() {
        if (!holdMode) return
        holdEnd = System.currentTimeMillis() + 500
    }

    fun stop() {
        running = false
        thread = null
    }

    /** Re-opens the mic, e.g. after switching the earbuds mic or the phone's filter. */
    fun restart() {
        if (!running) return
        stop()
        main.postDelayed({ start() }, 450)
    }

    private fun wantsWords(): Boolean =
        holdMode || Brain.wantsFull() || System.currentTimeMillis() < wakeUntil || Learn.training || Voiceprint.enrolling || kws == null

    @SuppressLint("MissingPermission")
    private fun loop(g: Int) {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        Sound.routeToEarbuds()
        val source = if (Sound.filterOn()) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val rec = try {
            AudioRecord(
                source, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 6400) * 2
            )
        } catch (e: Throwable) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            Buddy.status = "Couldn't open the microphone. Is another app using it?"
            running = false
            return
        }
        Sound.attachEffects(rec)
        rec.startRecording()
        val buf = ShortArray(512)
        var wasSpeaking = false
        try {
            while (running && g == gen) {
                // walkie mode: the button is up, so finish the last sentence and close the mic
                if (holdMode && holdEnd != 0L && System.currentTimeMillis() > holdEnd) {
                    val v0 = vad
                    if (v0 != null) {
                        v0.flush()
                        while (!v0.empty()) {
                            val seg = v0.front()
                            v0.pop()
                            onSentence(seg.samples)
                        }
                        v0.reset()
                    }
                    live.clear(); liveSamples = 0; wasSpeaking = false
                    holdMode = false
                    level = 0f
                    break
                }
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                val s = FloatArray(n) { buf[it] / 32768f }
                remember(s)
                var sum = 0f
                for (x in s) sum += x * x
                val rms = kotlin.math.sqrt(sum / n)
                level = (rms * 14f).coerceIn(0f, 1f)
                val awakeOk = holdMode || !Buddy.sleeping || Brain.forced || Learn.training || Voiceprint.enrolling
                if (!awakeOk) { vad?.reset(); live.clear(); liveSamples = 0; continue }
                val talking = Speaker.busy()

                // 1. the wake word
                val k = kws
                val ks = kwsStream
                // while Wave talks, only the wake word gets through, and only with the echo filter on
                // (it removes Wave's own voice from the mic), so "Hey Wave" can interrupt it
                if (!holdMode && k != null && ks != null && !kwsDirty && Store.b("wakeon", true) && (!talking || Sound.filterOn())) {
                    ks.acceptWaveform(s, RATE)
                    while (k.isReady(ks)) {
                        k.decode(ks)
                        if (k.getResult(ks).keyword.isNotBlank()) {
                            k.reset(ks)
                            if (talking) Speaker.stop()
                            onWakeWord()
                        }
                    }
                }

                // while Wave is talking, don't turn Wave's own voice into words
                if (talking) {
                    vad?.reset(); live.clear(); liveSamples = 0; wasSpeaking = false
                    level = 0f
                    continue
                }

                // 2. cut the sound into sentences
                val v = vad ?: continue
                v.acceptWaveform(s)
                val speaking = v.isSpeechDetected()
                if (!speaking) noise = noise * 0.98f + rms * 0.02f
                val want = wantsWords()
                if (speaking && !wasSpeaking && want) {
                    main.post { Fx.state(RingState.HEAR) }
                    live.clear()
                    liveSamples = 0
                    val pre = lastSeconds(0.4f)
                    live.add(pre)
                    liveSamples += pre.size
                    lastLive = System.currentTimeMillis()
                } else if (speaking && want) {
                    live.add(s)
                    liveSamples += s.size
                    val now = System.currentTimeMillis()
                    if (now - lastLive > 700 && !liveBusy && liveSamples > RATE / 2 && liveSamples < RATE * 12) {
                        lastLive = now
                        val all = FloatArray(liveSamples)
                        var o = 0
                        for (a in live) { System.arraycopy(a, 0, all, o, a.size); o += a.size }
                        liveBusy = true
                        work.execute {
                            val t = transcribe(boost(all))
                            if (t.isNotBlank()) Buddy.heard = Norm.clean(t) + " \u2026"
                            liveBusy = false
                        }
                    }
                }
                wasSpeaking = speaking
                while (!v.empty()) {
                    val seg = v.front()
                    v.pop()
                    live.clear()
                    liveSamples = 0
                    onSentence(seg.samples)
                }
            }
        } catch (e: Throwable) {
            Buddy.status = "The microphone stopped: " + (e.message ?: e.javaClass.simpleName)
        }
        try { rec.stop() } catch (e: Throwable) { }
        rec.release()
        Sound.releaseEffects()
        if (g == gen) Sound.stopEarbuds()
        if (g == gen) running = false
    }

    private fun remember(s: FloatArray) {
        for (x in s) {
            ring[ringPos] = x
            ringPos++
            if (ringPos >= ring.size) { ringPos = 0; ringFull = true }
        }
    }

    private fun lastSeconds(secs: Float): FloatArray {
        val want = minOf((secs * RATE).toInt(), if (ringFull) ring.size else ringPos)
        val out = FloatArray(want)
        var p = ringPos - want
        if (p < 0) p += ring.size
        for (i in 0 until want) {
            out[i] = ring[p]
            p++
            if (p >= ring.size) p = 0
        }
        return out
    }

    private fun onWakeWord() {
        if (Voiceprint.lockOn()) {
            val sample = lastSeconds(1.6f)
            val emb = embed(sample)
            if (!Voiceprint.allows(emb, sample.size / RATE.toFloat())) return
        }
        wakeUntil = System.currentTimeMillis() + 8000
        Brain.onWakeWord()
    }

    private fun onSentence(samples: FloatArray) {
        val secs = samples.size / RATE.toFloat()
        if (secs < 0.3f) return
        if (!wantsWords()) return
        val copy = samples.copyOf()
        work.execute { understand(copy, secs) }
    }

    /** Makes quiet speech louder (the speech engine hears soft voices badly) without clipping loud ones. */
    private fun boost(x: FloatArray): FloatArray {
        var sum = 0.0
        var peak = 0f
        for (v in x) { sum += v * v; val a = kotlin.math.abs(v); if (a > peak) peak = a }
        val rms = kotlin.math.sqrt(sum / maxOf(1, x.size)).toFloat()
        if (rms <= 1e-5f) return x
        var gain = 0.08f / rms
        gain = gain.coerceIn(1f, 10f)
        if (peak * gain > 0.95f) gain = maxOf(1f, 0.95f / peak)
        if (gain <= 1.01f) return x
        return FloatArray(x.size) { x[it] * gain }
    }

    /** Takes out steady background noise, when switched on in Safety. */
    private fun denoise(x: FloatArray): FloatArray {
        val d = clean ?: return x
        val mode = Store.s("cleaner", "auto")
        if (mode == "off" || (mode == "auto" && !noisy())) return x
        return try {
            val out = d.run(x, RATE)
            if (out.sampleRate == RATE && out.samples.isNotEmpty()) out.samples else x
        } catch (e: Throwable) {
            x
        }
    }

    private fun understand(samples: FloatArray, secs: Float) {
        val needVoice = spk != null && (Voiceprint.enrolling || Voiceprint.enrolled)
        val emb = if (needVoice) embed(samples) else null
        main.post { Fx.state(RingState.THINK) }
        val text = transcribe(boost(denoise(samples)))
        if (Voiceprint.enrolling) {
            if (text.isNotBlank()) Buddy.heard = Norm.clean(text)
            Voiceprint.consume(emb, secs)
            return
        }
        if (text.isBlank()) {
            main.post { if (Buddy.phase == RingState.THINK) Fx.state(RingState.LISTEN) }
            return
        }
        if (!Voiceprint.allows(emb, secs)) {
            main.post { Fx.state(RingState.IDLE) }
            return
        }
        Brain.onFinal(text)
    }

    private fun transcribe(samples: FloatArray): String {
        val r = asr ?: return ""
        return try {
            val st = r.createStream()
            st.acceptWaveform(samples, RATE)
            r.decode(st)
            val t = r.getResult(st).text
            st.release()
            t
        } catch (e: Throwable) {
            ""
        }
    }

    private fun embed(samples: FloatArray): FloatArray? {
        val x = spk ?: return null
        if (samples.size < RATE / 2) return null
        return try {
            val st = x.createStream()
            st.acceptWaveform(samples, RATE)
            st.inputFinished()
            val out = if (x.isReady(st)) x.compute(st) else null
            st.release()
            out
        } catch (e: Throwable) {
            null
        }
    }
}
