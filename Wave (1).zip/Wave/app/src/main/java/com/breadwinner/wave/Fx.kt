package com.breadwinner.wave

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.View
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

enum class RingState { IDLE, LISTEN, HEAR, THINK, DONE, PROBLEM }

/** The one place everything else calls to show the glow and the floating words. */
object Fx {
    private val main = Handler(Looper.getMainLooper())

    fun state(s: RingState) {
        main.post {
            Buddy.phase = s
            Hands.inst?.fx?.setState(s)
            Hands.inst?.setFabMode()
        }
    }

    fun words(text: String, sub: String = "", hold: Int = 0) {
        main.post {
            val v = Hands.inst?.fx
            val ms = if (hold > 0) (hold * Store.holdMs / 1500f).toInt() else Store.holdMs
            if (v != null) v.showWords(text, sub, ms)
            else Toast.makeText(Store.app, if (sub.isNotEmpty()) "$text\n$sub" else text, Toast.LENGTH_SHORT).show()
        }
    }

    fun clearWords() {
        main.post { Hands.inst?.fx?.clearWords() }
    }

    fun palette(name: String): IntArray = when (name) {
        "jarvis" -> intArrayOf(0xFF3FD0FF.toInt(), 0xFF2A8BFF.toInt(), 0xFF9BF0FF.toInt())
        "sunset" -> intArrayOf(0xFFFFB86B.toInt(), 0xFFFF6B8B.toInt(), 0xFFB06BFF.toInt())
        "sea" -> intArrayOf(0xFF5ED4C8.toInt(), 0xFF6BA8FF.toInt(), 0xFFA78BFA.toInt())
        "moss" -> intArrayOf(0xFFB7D36B.toInt(), 0xFF6BD49A.toInt(), 0xFF6BC4D4.toInt())
        else -> intArrayOf(0xFFFF8A6B.toInt(), 0xFFA78BFA.toInt(), 0xFF7CB7FF.toInt())
    }

    fun textColor(name: String): Int = when (name) {
        "ice" -> 0xFFCFF4FF.toInt()
        "white" -> 0xFFFFFFFF.toInt()
        "peach" -> 0xFFFFD2B8.toInt()
        "coral" -> 0xFFFF9B80.toInt()
        "sky" -> 0xFFBFDFFF.toInt()
        "mint" -> 0xFFC8F2D8.toInt()
        "lilac" -> 0xFFDCCBFF.toInt()
        else -> 0xFFFFF4E6.toInt()
    }

    fun typeface(name: String): Typeface = when (name) {
        "bold" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        "casual" -> Typeface.create("casual", Typeface.NORMAL)
        "script" -> Typeface.create("cursive", Typeface.NORMAL)
        "serif" -> Typeface.create("serif", Typeface.BOLD)
        else -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
}

/** Paints the glowing ring. Shared by the live overlay and the calibration screen. */
object RingPainter {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val m = Matrix()

    fun draw(c: Canvas, cx: Float, cy: Float, r: Float, thick: Float, glow: Float, spin: Float, inten: Float, pal: IntArray) {
        if (inten <= 0.01f) return
        val rad = r + thick / 2f + 1f
        val sg = SweepGradient(cx, cy, intArrayOf(pal[0], pal[1], pal[2], pal[0]), null)
        m.setRotate(spin * 360f, cx, cy)
        sg.setLocalMatrix(m)
        p.shader = sg
        for (i in 6 downTo 1) {
            p.strokeWidth = thick + i * thick * 0.8f * (0.4f + glow)
            p.alpha = (255 * inten * 0.085f * (0.3f + glow)).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, rad, p)
        }
        p.strokeWidth = thick
        p.alpha = (255 * inten).toInt().coerceIn(0, 255)
        c.drawCircle(cx, cy, rad, p)
        p.shader = null
        p.strokeWidth = max(1f, thick * 0.28f)
        p.color = 0xFFFFFFFF.toInt()
        p.alpha = (110 * inten).toInt().coerceIn(0, 255)
        c.drawCircle(cx, cy, rad, p)
    }
}

class NumBadge(val n: Int, val r: Rect)

/** One full-screen see-through layer: ring, words, number badges and the screen grid. Touches pass straight through. */
class FxView(ctx: Context) : View(ctx) {
    private class Words(val text: String, val sub: String, val hold: Long, val t0: Long)

    private val dm = resources.displayMetrics
    private fun dp(v: Float) = v * dm.density
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, dm)

    private var state = RingState.IDLE
    private var stateT0 = System.currentTimeMillis()
    private var lastHear = 0L
    private var phase = 0f
    private var lastFrame = 0L
    private var words: Words? = null
    private var lay: StaticLayout? = null
    private var laySub: StaticLayout? = null
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val tps = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var scrim: RadialGradient? = null
    private var scrimKey = 0f

    var badges: List<NumBadge> = emptyList()
        set(v) { field = v; invalidate() }
    var gridRegion: RectF? = null
        set(v) { field = v; invalidate() }
    var gridLevel = 0
    var gridMark: android.graphics.PointF? = null

    fun setState(s: RingState) {
        if (s == RingState.HEAR) lastHear = System.currentTimeMillis()
        if (s == state && s != RingState.DONE && s != RingState.PROBLEM) { invalidate(); return }
        state = s
        stateT0 = System.currentTimeMillis()
        invalidate()
    }

    fun showWords(text: String, sub: String, holdMs: Int) {
        val w = (width * 0.86f).toInt().coerceAtLeast(200)
        tp.typeface = Fx.typeface(Store.font)
        tp.textSize = sp(Store.textSize.toFloat())
        tp.color = Fx.textColor(Store.textColor)
        tps.typeface = Fx.typeface("soft")
        tps.textSize = sp(max(14f, Store.textSize * 0.3f))
        tps.color = Fx.textColor(Store.textColor)
        lay = StaticLayout.Builder.obtain(text, 0, text.length, tp, w).setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 0.95f).build()
        laySub = if (sub.isNotEmpty()) StaticLayout.Builder.obtain(sub, 0, sub.length, tps, w).setAlignment(Layout.Alignment.ALIGN_CENTER).build() else null
        words = Words(text, sub, holdMs.toLong(), System.currentTimeMillis())
        invalidate()
    }

    fun clearWords() {
        words = null
        invalidate()
    }

    private fun ease(p: Float): Float = 1f - (1f - p).pow(3)
    private fun backOut(p: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        return 1f + c3 * (p - 1f).pow(3) + c1 * (p - 1f).pow(2)
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else min(0.1f, (now - lastFrame) / 1000f)
        lastFrame = now
        var anim = false

        // ring
        if (Store.ringOn) {
            val age = (now - stateT0) / 1000f
            if (state == RingState.HEAR && now - lastHear > 900) { state = RingState.LISTEN; stateT0 = now }
            if ((state == RingState.DONE && age > 0.7f) || (state == RingState.PROBLEM && age > 1.1f)) { state = RingState.IDLE; stateT0 = now }
            if ((state == RingState.LISTEN || state == RingState.HEAR || state == RingState.THINK) && age > 14f && !Brain.pttHeld) { state = RingState.IDLE; stateT0 = now }
            var inten: Float
            var speed: Float
            var pal = Fx.palette(Store.theme)
            when (state) {
                RingState.IDLE -> { inten = if (Store.ringIdle) 0.2f + 0.1f * sin(2f * PI.toFloat() * age / 3.2f) else 0f; speed = 0.04f }
                RingState.LISTEN -> { inten = 0.68f + 0.14f * sin(2f * PI.toFloat() * age / 1.2f); speed = 0.14f }
                RingState.HEAR -> { inten = 0.95f; speed = 0.4f }
                RingState.THINK -> { inten = 0.95f; speed = 1.0f }
                RingState.DONE -> { inten = 1f - 0.8f * min(1f, age / 0.7f); speed = 0.5f }
                RingState.PROBLEM -> { inten = 0.55f + 0.4f * sin(2f * PI.toFloat() * age / 0.55f).let { it * it }; speed = 0.1f; pal = intArrayOf(0xFFFF6B5E.toInt(), 0xFFFFB347.toInt(), 0xFFFF8A6B.toInt()) }
            }
            phase = (phase + dt * speed * Store.ringSpeed) % 1f
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = Store.ringX * w
            val cy = Store.ringY * h
            RingPainter.draw(c, cx, cy, Store.ringR * w, dp(Store.ringThick), Store.ringGlow, phase, inten, pal)
            if (Store.edgeGlow && inten > 0.3f) drawEdges(c, pal, inten)
            if (inten > 0.01f) anim = true
        }

        // words
        val wd = words
        if (wd != null) {
            if (!drawWords(c, wd, now)) words = null else anim = true
        }

        // numbers
        if (badges.isNotEmpty()) drawBadges(c)

        // grid
        val g = gridRegion
        if (g != null) drawGrid(c, g)

        if (anim) postInvalidateOnAnimation()
    }

    private fun drawEdges(c: Canvas, pal: IntArray, inten: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = dp(14f)
        val a = (150 * inten).toInt().coerceIn(0, 255)
        val col = (pal[1] and 0x00FFFFFF) or (a shl 24)
        val none = pal[1] and 0x00FFFFFF
        paint.shader = LinearGradient(0f, 0f, 0f, t, col, none, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, t, paint)
        paint.shader = LinearGradient(0f, h, 0f, h - t, col, none, Shader.TileMode.CLAMP); c.drawRect(0f, h - t, w, h, paint)
        paint.shader = LinearGradient(0f, 0f, t, 0f, col, none, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, t, h, paint)
        paint.shader = LinearGradient(w, 0f, w - t, 0f, col, none, Shader.TileMode.CLAMP); c.drawRect(w - t, 0f, w, h, paint)
        paint.shader = null
    }

    /** Returns false when the words have finished. */
    private fun drawWords(c: Canvas, wd: Words, now: Long): Boolean {
        val l = lay ?: return false
        val style = Store.style
        val enter = if (style == "drop") 1100L else 420L
        val exit = 480L
        val t = now - wd.t0
        if (t > enter + wd.hold + exit) return false
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = Store.posY * h
        val subH = laySub?.height?.toFloat() ?: 0f
        val gap = if (laySub != null) dp(10f) else 0f
        val totalH = l.height + gap + subH
        var alpha = 1f
        var scale = 1f
        var ty = 0f
        val q = if (t > enter + wd.hold) (t - enter - wd.hold) / exit.toFloat() else 0f

        when (style) {
            "float" -> {
                val p = min(1f, t / enter.toFloat())
                val e = ease(p)
                ty = (1f - e) * (h - cy + totalH)
                alpha = min(1f, p * 2.2f)
                if (q > 0) { alpha = 1f - q; ty = -dp(50f) * q }
            }
            "fade" -> {
                val p = min(1f, t / enter.toFloat())
                alpha = ease(p)
                scale = 0.94f + 0.06f * ease(p)
                if (q > 0) { alpha = 1f - q; scale = 1f + 0.05f * q }
            }
            else -> {
                val fall = 620L
                val ox = if (Store.ringOn) Store.ringX * w else w / 2f
                val oy = if (Store.ringOn) Store.ringY * h else dp(24f)
                val col = Fx.palette(Store.theme)[0]
                if (t < fall) {
                    val p = t / fall.toFloat()
                    val y = oy + (cy - oy) * p * p
                    val r = dp(11f)
                    paint.style = Paint.Style.FILL
                    paint.shader = null
                    paint.color = col
                    paint.alpha = 235
                    c.save()
                    c.translate(ox + (cx - ox) * p, y)
                    c.scale(1f - 0.2f * p, 1f + 0.8f * p)
                    c.drawCircle(0f, 0f, r, paint)
                    paint.color = 0xFFFFFFFF.toInt()
                    paint.alpha = 140
                    c.drawCircle(-r * 0.3f, -r * 0.3f, r * 0.3f, paint)
                    c.restore()
                    alpha = 0f
                } else {
                    val tt = (t - fall) / 480f
                    val rp = min(1f, (t - fall) / 560f)
                    paint.style = Paint.Style.STROKE
                    for (k in 0..1) {
                        val rk = (t - fall - k * 130L) / 560f
                        if (rk in 0f..1f) {
                            paint.color = col
                            paint.alpha = (150 * (1f - rk)).toInt()
                            paint.strokeWidth = dp(3f)
                            c.drawCircle(cx, cy, dp(20f) + dp(170f) * ease(rk), paint)
                        }
                    }
                    paint.style = Paint.Style.FILL
                    val tp0 = min(1f, tt)
                    alpha = tp0
                    scale = 0.35f + 0.65f * backOut(tp0)
                    if (q > 0) { alpha = 1f - q; scale = 1f + 0.03f * q; ty = dp(26f) * q }
                    if (rp < 0f) alpha = 0f
                }
            }
        }
        if (alpha <= 0.01f) return true

        // a soft dark glow behind the words so they stay readable on bright screens
        val sr = max(w * 0.55f, 100f)
        val key = cx + cy + sr
        if (scrim == null || key != scrimKey) {
            scrim = RadialGradient(cx, cy, sr, 0x40000000, 0x00000000, Shader.TileMode.CLAMP)
            scrimKey = key
        }
        paint.shader = scrim
        paint.alpha = (255 * alpha).toInt().coerceIn(0, 255)
        c.drawRect(0f, cy - sr, w, cy + sr, paint)
        paint.shader = null

        val glow = Fx.palette(Store.theme)[0]
        val a255 = (255 * alpha).toInt().coerceIn(0, 255)
        c.save()
        c.translate(cx, cy + ty)
        c.scale(scale, scale)
        c.translate(-l.width / 2f, -totalH / 2f)
        tp.alpha = a255
        tp.setShadowLayer(dp(18f), 0f, 0f, (glow and 0x00FFFFFF) or ((a255 * 0.9f).toInt() shl 24))
        l.draw(c)
        tp.setShadowLayer(dp(3f), 0f, dp(1.5f), (0x66 * alpha).toInt() shl 24)
        l.draw(c)
        val ls = laySub
        if (ls != null) {
            c.translate(0f, l.height + gap)
            tps.alpha = (a255 * 0.9f).toInt()
            tps.setShadowLayer(dp(6f), 0f, dp(1.5f), (0x88 * alpha).toInt() shl 24)
            ls.draw(c)
        }
        c.restore()
        return true
    }

    private fun drawBadges(c: Canvas) {
        val r = dp(8f)
        paint.textSize = sp(12f)
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        for (b in badges) {
            val txt = b.n.toString()
            val tw = paint.measureText(txt)
            val bw = max(dp(22f), tw + dp(10f))
            val bh = dp(20f)
            var x = b.r.left + dp(2f)
            var y = b.r.top + dp(2f)
            x = x.coerceIn(0f, width - bw)
            y = y.coerceIn(0f, height - bh)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(1.5f)
            paint.color = 0x88E8785A.toInt()
            c.drawRoundRect(RectF(b.r), r, r, paint)
            paint.style = Paint.Style.FILL
            paint.color = 0xF2E8785A.toInt()
            c.drawRoundRect(RectF(x, y, x + bw, y + bh), r, r, paint)
            paint.color = 0xFFFFFFFF.toInt()
            c.drawText(txt, x + bw / 2f, y + bh / 2f + paint.textSize * 0.35f, paint)
        }
        paint.textAlign = Paint.Align.LEFT
        paint.style = Paint.Style.FILL
    }

    private fun drawGrid(c: Canvas, g: RectF) {
        paint.style = Paint.Style.FILL
        paint.color = 0x22000000
        c.drawRect(0f, 0f, width.toFloat(), g.top, paint)
        c.drawRect(0f, g.bottom, width.toFloat(), height.toFloat(), paint)
        c.drawRect(0f, g.top, g.left, g.bottom, paint)
        c.drawRect(g.right, g.top, width.toFloat(), g.bottom, paint)
        val cw = g.width() / 3f
        val ch = g.height() / 3f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(2f)
        paint.color = 0xCCFFFFFF.toInt()
        paint.setShadowLayer(dp(3f), 0f, 0f, 0xAA000000.toInt())
        for (i in 0..3) {
            c.drawLine(g.left + i * cw, g.top, g.left + i * cw, g.bottom, paint)
            c.drawLine(g.left, g.top + i * ch, g.right, g.top + i * ch, paint)
        }
        paint.clearShadowLayer()
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        val ts = min(sp(40f), min(cw, ch) * 0.4f)
        paint.textSize = ts
        var n = 1
        for (row in 0..2) for (col in 0..2) {
            val x = g.left + cw * (col + 0.5f)
            val y = g.top + ch * (row + 0.5f)
            paint.color = 0x99E8785A.toInt()
            c.drawCircle(x, y, ts * 0.8f, paint)
            paint.color = 0xFFFFFFFF.toInt()
            c.drawText(n.toString(), x, y + ts * 0.35f, paint)
            n++
        }
        val m = gridMark
        if (m != null) {
            paint.color = 0xFF7CB7FF.toInt()
            c.drawCircle(m.x, m.y, dp(9f), paint)
        }
        paint.textAlign = Paint.Align.LEFT
    }
}

/** The little round button you can drag anywhere. Hold it to talk. */
/** The round mic button: a small Jarvis core that sits on the edge of the screen. */
class FabView(ctx: Context) : View(ctx) {
    var mode = 0                 // 0 normal, 1 paused, 2 recording, 3 talking
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val box = RectF()
    private var spin = 0f

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s / 2f - 3f
        val accent = when (mode) {
            1 -> 0xFF6F86A0.toInt()
            2 -> 0xFFFF5C6C.toInt()
            else -> 0xFF3FD0FF.toInt()
        }
        // dark glass disc
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = 0xF006101D.toInt()
        paint.setShadowLayer(s * 0.12f, 0f, s * 0.04f, (accent and 0x00FFFFFF) or 0x66000000)
        c.drawCircle(cx, cy, r, paint)
        paint.clearShadowLayer()
        // inner glow while talking
        if (mode == 3) {
            paint.shader = RadialGradient(cx, cy, r, (accent and 0x00FFFFFF) or 0x77000000, 0x00000000, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, paint)
            paint.shader = null
        }
        // segmented outer ring
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = s * 0.045f
        paint.color = accent
        val rr = r - s * 0.06f
        box.set(cx - rr, cy - rr, cx + rr, cy + rr)
        for (i in 0 until 3) c.drawArc(box, spin + i * 120f, 80f, false, paint)
        paint.strokeWidth = s * 0.018f
        paint.color = (accent and 0x00FFFFFF) or 0x66000000
        val r2 = r - s * 0.14f
        box.set(cx - r2, cy - r2, cx + r2, cy + r2)
        for (i in 0 until 12) c.drawArc(box, -spin * 0.6f + i * 30f, 14f, false, paint)
        paint.color = accent
        if (mode == 2) {
            paint.style = Paint.Style.FILL
            c.drawRoundRect(cx - s * 0.12f, cy - s * 0.12f, cx + s * 0.12f, cy + s * 0.12f, s * 0.04f, s * 0.04f, paint)
            return
        }
        // the mic
        paint.style = Paint.Style.FILL
        c.drawRoundRect(cx - s * 0.065f, cy - s * 0.17f, cx + s * 0.065f, cy + s * 0.035f, s * 0.065f, s * 0.065f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.035f
        path.reset()
        path.addArc(RectF(cx - s * 0.115f, cy - s * 0.10f, cx + s * 0.115f, cy + s * 0.10f), 0f, 180f)
        c.drawPath(path, paint)
        c.drawLine(cx, cy + s * 0.10f, cx, cy + s * 0.165f, paint)
        // keep turning while there's something going on
        if (mode == 3 || (mode == 0 && Buddy.phase != RingState.IDLE)) {
            spin = (spin + if (mode == 3) 6f else 2.5f) % 360f
            postInvalidateOnAnimation()
        }
    }
}
