package com.breadwinner.wave

class Plan(
    val label: String,
    val steps: List<Step>,
    val risky: Boolean = false,
    val trivial: Boolean = false,
    val ask: Boolean = false
)

class Res(val plan: Plan? = null, val ask: Boolean = false, val fail: String = "")

/** Turns what you said into steps. Your own commands come first, then the built-in words. */
object Parser {
    private class Fixed(val phrases: List<String>, val plan: Plan)

    private val fixed = ArrayList<Fixed>()

    private fun reg(phrases: List<String>, label: String, vararg steps: Step, risky: Boolean = false, trivial: Boolean = true) {
        fixed.add(Fixed(phrases, Plan(label, steps.toList(), risky, trivial)))
    }

    init {
        reg(listOf("go back", "back", "back button", "press back"), "Back", Step("BACK"))
        reg(listOf("go home", "home", "home screen", "press home"), "Home", Step("HOME"))
        reg(listOf("recents", "recent apps", "show recents", "open recents", "app switcher"), "Recent apps", Step("RECENTS"))
        reg(listOf("notifications", "open notifications", "show notifications", "pull down notifications"), "Notifications", Step("NOTIFS"))
        reg(listOf("quick settings", "open quick settings"), "Quick settings", Step("QUICK"))
        reg(listOf("lock", "lock screen", "lock the screen", "lock phone", "lock the phone"), "Locking", Step("LOCK"))
        reg(listOf("screenshot", "take a screenshot", "take screenshot"), "Screenshot", Step("SHOT"))
        reg(listOf("power menu"), "Power menu", Step("POWER"))
        for (d in listOf("down", "up", "left", "right")) {
            reg(listOf("scroll $d", "swipe $d", "page $d"), "Scroll $d", Step("SCROLL", d))
        }
        reg(listOf("scroll faster", "faster"), "Scrolling faster", Step("SCROLL_SPEED", "faster"))
        reg(listOf("scroll slower", "slower"), "Scrolling slower", Step("SCROLL_SPEED", "slower"))
        reg(listOf("show numbers", "numbers on", "numbers", "show number"), "Numbers", Step("NUMS_ON"))
        reg(listOf("hide numbers", "numbers off", "hide number", "clear numbers"), "Numbers off", Step("NUMS_OFF"))
        reg(listOf("show grid", "grid", "grid on", "screen grid"), "Grid", Step("GRID_ON"))
        reg(listOf("hide grid", "close grid", "grid off"), "Grid off", Step("GRID_OFF"))
        reg(listOf("grid back", "zoom out"), "Zooming out", Step("GRID_UP"))
        reg(listOf("tap", "click", "tap here", "click here", "press", "select"), "Tap", Step("GRID_TAP"))
        reg(listOf("long press", "hold", "long press here", "hold here"), "Long press", Step("GRID_LONG"))
        reg(listOf("grab", "pick up", "grab here"), "Grabbed", Step("GRID_GRAB"))
        reg(listOf("drop", "drop here", "let go"), "Dropped", Step("GRID_DROP"))
        reg(listOf("start typing", "dictation", "dictation mode", "start dictation"), "Typing mode", Step("DICTATE_ON"))
        reg(listOf("stop typing", "stop dictation", "done typing", "end dictation"), "Typing mode off", Step("DICTATE_OFF"))
        reg(listOf("send", "send it", "press send", "send message", "send that"), "Send", Step("SEND"), risky = true, trivial = false)
        reg(listOf("delete that", "undo", "undo that", "scratch that"), "Deleted", Step("UNDO_TYPE"))
        reg(listOf("clear text", "clear all", "clear the text", "clear field"), "Cleared", Step("CLEAR_TEXT"))
        reg(listOf("new line", "next line"), "New line", Step("TYPE", "\n"))
        reg(listOf("flashlight", "torch", "toggle flashlight", "toggle torch"), "Flashlight", Step("TORCH", "toggle"))
        reg(listOf("flashlight on", "torch on", "turn on flashlight", "turn on the flashlight", "turn on torch", "turn on the torch"), "Flashlight on", Step("TORCH", "on"))
        reg(listOf("flashlight off", "torch off", "turn off flashlight", "turn off the flashlight", "turn off torch", "turn off the torch"), "Flashlight off", Step("TORCH", "off"))
        reg(listOf("volume up", "turn up the volume", "louder", "turn it up"), "Volume up", Step("VOLUME", "up"))
        reg(listOf("volume down", "turn down the volume", "quieter", "softer", "turn it down"), "Volume down", Step("VOLUME", "down"))
        reg(listOf("mute", "silence"), "Muted", Step("VOLUME", "mute"))
        reg(listOf("unmute"), "Unmuted", Step("VOLUME", "unmute"))
        reg(listOf("wifi", "wi fi", "internet", "internet settings", "wifi settings"), "Wi-Fi panel", Step("PANEL", "internet"))
        reg(listOf("bluetooth", "bluetooth settings"), "Bluetooth", Step("PANEL", "bluetooth"))
        reg(listOf("read the screen", "read screen", "what's on the screen", "whats on the screen", "what's on screen"), "Reading the screen", Step("READ_SCREEN"))
        reg(listOf("sleep", "go to sleep", "stop listening", "pause listening"), "Sleeping", Step("SLEEP"))
        reg(listOf("cancel", "stop", "never mind", "nevermind", "forget it"), "Cancelled", Step("CANCEL"))
        reg(listOf("help", "what can you do", "show commands", "commands"), "Help", Step("HELP"))
        reg(listOf("teach a command", "teach command", "learn a command", "teach me a command", "new command", "teach a new command"), "Teaching", Step("TEACH"))
    }

    private fun fixBrands(t: String): String {
        var s = " $t "
        val pairs = listOf(
            " what's app " to " whatsapp ", " whats app " to " whatsapp ", " what's up " to " whatsapp ", " watts app " to " whatsapp ",
            " face book " to " facebook ", " you tube " to " youtube ", " insta gram " to " instagram ", " tick tock " to " tiktok ",
            " tik tok " to " tiktok ", " g mail " to " gmail ", " play store " to " play store "
        )
        for ((a, b) in pairs) s = s.replace(a, b)
        return s.trim()
    }

    fun parse(raw: String): Res {
        val w0 = Norm.words(raw)
        if (w0.isEmpty()) return Res()
        val w = fixBrands(w0.joinToString(" ")).split(" ").filter { it.isNotEmpty() }
        val t = w.joinToString(" ")

        // a lone number: tap that number, or pick that grid square
        val h = Hands.inst
        if (h != null) {
            val n = Norm.looseNumber(w)
            if (n != null && h.numbersOn) return Res(Plan("Tap $n", listOf(Step("TAP_NUM", n = n)), trivial = true))
            if (n != null && h.gridOn && n in 1..9) return Res(Plan("Square $n", listOf(Step("GRID_PICK", n = n)), trivial = true))
        }

        // your own commands win over built-ins
        var nearCmd: Command? = null
        var nearScore = 0f
        for (c in Store.cmds) {
            if (!c.enabled) continue
            val m = Norm.match(c.phrase, w)
            if (m != null) return Res(planOf(c, m))
            if (!c.phrase.contains("{")) {
                val sc = Norm.sim(Norm.clean(c.phrase), t)
                if (sc > nearScore) { nearScore = sc; nearCmd = c }
            }
        }

        for (f in fixed) if (f.phrases.contains(t)) return gate(Res(f.plan))

        templates(w)?.let { return gate(it) }

        // nearly right? offer it
        if (nearCmd != null && nearScore >= 0.86f) return Res(planOf(nearCmd, emptyMap()), ask = true)
        var bestF: Fixed? = null
        var bs = 0f
        for (f in fixed) for (p in f.phrases) {
            if (p.length < 5) continue
            val sc = Norm.sim(p, t)
            if (sc > bs) { bs = sc; bestF = f }
        }
        if (bestF != null && bs >= 0.84f) return Res(bestF.plan, ask = true)
        return Res()
    }

    val groups = listOf(
        Triple("apps", "Open apps", "\"open WhatsApp\""),
        Triple("nav", "Back, home, recents, lock, screenshot", "\"go back\", \"go home\""),
        Triple("scroll", "Scroll and swipe", "\"scroll down\""),
        Triple("tap", "Tap by name, numbers and grid", "\"tap Send\", \"show numbers\", \"grid\""),
        Triple("type", "Typing and dictation", "\"type hello\", \"start typing\", \"send\""),
        Triple("call", "Calling", "\"call Dad\""),
        Triple("alarm", "Timers and alarms", "\"timer five minutes\""),
        Triple("phone", "Flashlight, volume, Wi-Fi, read screen", "\"flashlight on\"")
    )

    private fun groupOf(t: String): String? = when (t) {
        "OPEN_APP" -> "apps"
        "BACK", "HOME", "RECENTS", "NOTIFS", "QUICK", "LOCK", "SHOT", "POWER" -> "nav"
        "SCROLL", "SCROLL_SPEED" -> "scroll"
        "TAP_TEXT", "TAP_NUM", "LONG_TEXT", "LONG_NUM", "NUMS_ON", "NUMS_OFF", "GRID_ON", "GRID_OFF", "GRID_UP",
        "GRID_PICK", "GRID_TAP", "GRID_LONG", "GRID_GRAB", "GRID_DROP" -> "tap"
        "TYPE", "SEND", "UNDO_TYPE", "CLEAR_TEXT", "DICTATE_ON", "DICTATE_OFF" -> "type"
        "CALL" -> "call"
        "TIMER", "ALARM" -> "alarm"
        "TORCH", "VOLUME", "PANEL", "READ_SCREEN" -> "phone"
        else -> null
    }

    private fun gate(r: Res): Res {
        val p = r.plan ?: return r
        for (s in p.steps) {
            val g = groupOf(s.type) ?: continue
            if (!Store.b("bi_$g", true)) return Res(fail = "That command is switched off in Commands.")
        }
        return r
    }

    private fun planOf(c: Command, vars: Map<String, String>): Plan {
        val steps = c.steps.map { s ->
            var a = s.a
            var b = s.b
            for ((k, v) in vars) {
                val vv = if (s.type == "TYPE") Norm.pretty(v) else v
                a = a.replace("{$k}", vv)
                b = b.replace("{$k}", vv)
            }
            Step(s.type, a, b, s.n)
        }
        var label = c.phrase
        for ((k, v) in vars) label = label.replace("{$k}", v)
        label = label.replaceFirstChar { it.uppercase() }
        val risky = steps.any { it.type == "CALL" || it.type == "SEND" || it.type == "WA_CHAT" && steps.any { x -> x.type == "TYPE" } }
        return Plan(label, steps, risky, false, c.ask)
    }

    private fun digits(w: List<String>): String? {
        val sb = StringBuilder()
        for (x in w) {
            val n = Norm.looseNumber(listOf(x)) ?: return null
            if (n > 9 && x.length < 2) return null
            sb.append(n.toString())
        }
        return if (sb.length >= 5) sb.toString() else null
    }

    private fun templates(w: List<String>): Res? {
        fun m(vararg tpls: String): Map<String, String>? {
            for (t in tpls) Norm.match(t, w)?.let { return it }
            return null
        }

        m("open {app}", "launch {app}", "start {app}", "open up {app}")?.let {
            val said = it["app"] ?: return null
            val hit = Apps.find(said) ?: return Res(fail = "I couldn't find an app called \"$said\".")
            if (hit.second < 0.6f) return Res(fail = "I couldn't find an app called \"$said\".")
            val p = Plan("Opening ${hit.first.label}", listOf(Step("OPEN_APP", hit.first.pkg)), trivial = true)
            return Res(p, ask = hit.second < 0.8f)
        }
        m("long press {x}", "hold {x}")?.let {
            val x = it["x"] ?: return null
            val n = Norm.looseNumber(x.split(" "))
            return Res(Plan("Long press $x", listOf(if (n != null) Step("LONG_NUM", n = n) else Step("LONG_TEXT", x)), trivial = true))
        }
        m("tap {x}", "click {x}", "press {x}", "select {x}")?.let {
            val x = it["x"] ?: return null
            val n = Norm.looseNumber(x.split(" "))
            return Res(Plan("Tap $x", listOf(if (n != null) Step("TAP_NUM", n = n) else Step("TAP_TEXT", x)), trivial = true))
        }
        m("type {text}", "write {text}", "enter text {text}")?.let {
            val x = Norm.pretty(it["text"] ?: return null)
            return Res(Plan("Typing", listOf(Step("TYPE", x)), trivial = true))
        }
        m("call {name} on speaker", "call {name} on speakerphone", "phone {name} on speaker")?.let { return callPlan(it["name"] ?: return null, true) }
        m("call {name}", "phone {name}", "dial {name}", "ring {name}")?.let { return callPlan(it["name"] ?: return null, false) }
        m("set a timer for {t}", "set timer for {t}", "timer for {t}", "start a timer for {t}", "set a timer {t}", "timer {t}")?.let {
            val secs = Norm.duration(it["t"]!!.split(" ")) ?: return Res(fail = "I didn't get how long the timer should be.")
            return Res(Plan("Timer for ${spell(secs)}", listOf(Step("TIMER", n = secs)), trivial = true))
        }
        m("set an alarm for {t}", "set alarm for {t}", "alarm for {t}", "alarm {t}", "wake me at {t}", "wake me up at {t}", "set an alarm at {t}")?.let {
            val c = Norm.clock(it["t"]!!.split(" ")) ?: return Res(fail = "I didn't get what time the alarm should be.")
            val hh = c.first.toString().padStart(2, '0')
            val mm = c.second.toString().padStart(2, '0')
            return Res(Plan("Alarm at $hh:$mm", listOf(Step("ALARM", "$hh:$mm")), trivial = true))
        }
        // call 0 7 8 0 ... digits
        return null
    }

    private fun callPlan(said: String, speaker: Boolean): Res {
        val ds = digits(said.split(" "))
        if (ds != null) {
            val steps = arrayListOf(Step("CALL", ds))
            if (speaker) steps.add(Step("SPEAKER"))
            return Res(Plan("Call $ds", steps, risky = true))
        }
        if (!Contacts.granted()) return Res(fail = "I need permission to read your contacts. Open Wave to allow it.")
        val hit = Contacts.find(said) ?: return Res(fail = "I couldn't find \"$said\" in your contacts.")
        if (hit.second < 0.62f) return Res(fail = "I couldn't find \"$said\" in your contacts.")
        val steps = arrayListOf(Step("CALL", hit.first.name))
        if (speaker) steps.add(Step("SPEAKER"))
        return Res(Plan("Call ${hit.first.name}", steps, risky = true), ask = hit.second < 0.8f)
    }

    private fun spell(secs: Int): String {
        val h = secs / 3600
        val m = secs % 3600 / 60
        val s = secs % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h hr")
        if (m > 0) parts.add("$m min")
        if (s > 0) parts.add("$s sec")
        return parts.joinToString(" ")
    }

    /** The plain-words list shown for "help". */
    val helpLines = listOf(
        "open an app: \"open WhatsApp\"",
        "call someone: \"call Dad\"",
        "tap by name: \"tap Send\"",
        "tap by number: \"show numbers\", then \"tap 12\"",
        "anywhere: \"grid\", then a number from 1 to 9",
        "typing: \"type hello\" or \"start typing\"",
        "teach me: \"teach a command\""
    )
}
