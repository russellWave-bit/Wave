package com.breadwinner.wave

import android.Manifest
import android.content.ComponentName
import androidx.core.view.WindowCompat
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.SideEffect
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// Jarvis: deep navy night with cyan light by default, or an ice-blue daylight version.
// Every colour is read from the current look, so switching looks repaints the whole app.
fun night(): Boolean = Store.s("ui", "night") != "day"

private fun pick(n: Long, d: Long): Color = Color(if (night()) n else d)

val Cream: Color get() = pick(0xFF06101D, 0xFFEAF3FB)     // the page
val Peach: Color get() = pick(0xFF11223A, 0xFFDCE9F6)     // wells, tracks, unselected chips
val Paper: Color get() = pick(0xFF0B192B, 0xFFF8FBFE)     // panels
val Ink: Color get() = pick(0xFFDCEBFA, 0xFF12263F)       // main text
val Mute: Color get() = pick(0xFF7F9BB8, 0xFF657D97)      // quiet text
val Coral: Color get() = pick(0xFF3FD0FF, 0xFF1E7FD9)     // the accent: buttons, highlights
val OnAccent: Color get() = pick(0xFF04121F, 0xFFFFFFFF)  // text on the accent
val Violet: Color get() = pick(0xFF2A8BFF, 0xFF4BA3F0)    // listening
val SkyBlue: Color get() = pick(0xFF9BF0FF, 0xFF8FD3FF)   // thinking
val Good: Color get() = pick(0xFF3DDC97, 0xFF1F9D6A)
val Bad: Color get() = pick(0xFFFF5C6C, 0xFFD94B57)
val Hair: Color get() = pick(0x333FD0FF, 0x2212263F)

@Composable
fun Tx(
    text: String, size: Int = 14, color: Color = Ink,
    weight: FontWeight = FontWeight.SemiBold, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

fun Modifier.sky(): Modifier = this.background(Cream)

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Paper, shape)
            .border(1.dp, Hair, shape)
            .padding(18.dp),
        content = content
    )
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, filled: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fill = if (filled) (if (enabled) Coral else Coral.copy(alpha = 0.4f)) else Paper
    Box(
        modifier
            .clip(shape)
            .background(fill, shape)
            .border(1.dp, if (filled) Color.Transparent else Hair, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Tx(text, 14, if (filled) OnAccent else if (enabled) Ink else Mute)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(if (selected) Coral else Peach, shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Tx(text, 13, if (selected) OnAccent else Ink) }
}

@Composable
fun ToggleRow(title: String, sub: String = "", on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Tx(title, 14)
            if (sub.isNotEmpty()) Tx(sub, 12, Mute, FontWeight.Normal)
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Coral, checkedThumbColor = OnAccent,
                uncheckedTrackColor = Peach, uncheckedThumbColor = Mute, uncheckedBorderColor = Hair
            )
        )
    }
}

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Peach).padding(3.dp)) {
        options.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(50)).background(if (i == sel) Paper else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) { Tx(s, 12, if (i == sel) Coral else Mute) }
        }
    }
}

@Composable
fun TextBox(value: String, hint: String, modifier: Modifier = Modifier, numbers: Boolean = false, onChange: (String) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.fillMaxWidth().clip(shape).background(Cream, shape).border(1.dp, Hair, shape)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        if (value.isEmpty()) Tx(hint, 14, Mute, FontWeight.Normal)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = 15.sp),
            cursorBrush = SolidColor(Coral),
            keyboardOptions = KeyboardOptions(keyboardType = if (numbers) KeyboardType.Number else KeyboardType.Text),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row {
            Tx(title, 13, modifier = Modifier.weight(1f))
            Tx(shown, 12, Mute, FontWeight.Normal)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Coral, activeTrackColor = Coral, inactiveTrackColor = Peach)
        )
    }
}

@Composable
fun Swatches(colors: List<Pair<String, Color>>, sel: String, onSel: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for ((k, c) in colors) {
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(c).border(if (k == sel) 3.dp else 1.dp, if (k == sel) Ink else Hair, CircleShape)
                    .clickable { onSel(k) }
            )
        }
    }
}

@Composable
fun Header(title: String, sub: String = "", onBack: (() -> Unit)? = null, action: String = "Done") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Tx(title, 28, weight = FontWeight.Medium)
            if (sub.isNotEmpty()) Tx(sub, 14, Mute, FontWeight.Normal)
        }
        if (onBack != null) Btn(action, filled = true, onClick = onBack)
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

/**
 * The orb: one soft ball of light that breathes. Sage when resting, lilac when it hears you,
 * sky blue while it works, still and grey when it's off.
 */
@Composable
fun Blob(level: Int, modifier: Modifier = Modifier, height: Dp = 180.dp) {
    val tr = rememberInfiniteTransition(label = "orb")
    val ms = when (level) { 2 -> 1600; 1 -> 3600; else -> 7000 }
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing)), label = "t")
    val core = when (level) { 2 -> Violet; 1 -> Coral; else -> Color(0xFFB9C6C2) }
    val halo = when (level) { 2 -> SkyBlue; 1 -> Violet; else -> Peach }
    Canvas(modifier.fillMaxWidth().height(height)) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val base = min(size.width, size.height) * 0.34f
        val breathe = 1f + 0.06f * sin(2f * PI.toFloat() * t)
        val r = base * breathe
        drawCircle(Brush.radialGradient(listOf(halo.copy(alpha = 0.35f), Color.Transparent), c, r * 1.5f), r * 1.5f, c)
        drawCircle(Brush.radialGradient(listOf(core.copy(alpha = 0.95f), core.copy(alpha = 0.55f), halo.copy(alpha = 0.25f)), c, r), r, c)
        val hl = Offset(c.x - r * 0.3f, c.y - r * 0.35f)
        drawCircle(Brush.radialGradient(listOf(Color(0x66FFFFFF), Color.Transparent), hl, r * 0.5f), r * 0.5f, hl)
        if (level > 0) {
            val ring = r * (1.15f + 0.25f * t)
            drawCircle(core.copy(alpha = 0.25f * (1f - t)), ring, c, style = Stroke(width = 2.dp.toPx()))
        }
    }
}

// ---- permission and setting checks

fun has(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

fun wantedPerms(): Array<String> {
    val l = arrayListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    return l.toTypedArray()
}

fun accOn(c: Context): Boolean {
    val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    val me = ComponentName(c, Hands::class.java).flattenToString()
    return s.split(":").any { it.equals(me, true) }
}

fun batOk(c: Context): Boolean =
    (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)

fun openSettings(c: Context, action: String) {
    try { c.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
}

fun openAppInfo(c: Context) {
    try {
        c.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) { }
}

fun askBattery(c: Context) {
    try {
        c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSettings(c, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    }
}

@Composable
fun resumeTick(): Int {
    var t by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) t++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    return t
}

@Composable
fun CheckRow(text: String, done: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(24.dp).clip(CircleShape).background(if (done) Good else Peach), contentAlignment = Alignment.Center) {
            if (done) Tx("✓", 14, OnAccent)
        }
        Spacer(Modifier.width(10.dp))
        Tx(text, 14, modifier = Modifier.weight(1f))
        if (!done && action.isNotEmpty()) Btn(action, filled = true, onClick = onClick)
    }
}

enum class Pg { Home, Menu, Hearing, Commands, Edit, Look, Safety, Vocab, Try, Setup, Calibrate, Train, Mine, Talk, Voice, Lately }

@Composable
fun WaveBuddyApp() {
    var page by remember { mutableStateOf(if (Store.b("setupdone", false)) Pg.Home else Pg.Setup) }
    var editing by remember { mutableStateOf<Command?>(null) }
    var calibBack by remember { mutableStateOf(Pg.Look) }
    val view = LocalView.current
    val dark = night()
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    BackHandler(enabled = page != Pg.Home) {
        page = when (page) {
            Pg.Edit -> Pg.Commands
            Pg.Calibrate -> calibBack
            Pg.Menu, Pg.Setup -> Pg.Home
            else -> Pg.Menu
        }
    }
    if (!Engines.installed) {
        Box(Modifier.fillMaxSize().sky()) { EnginePage() }
        return
    }
    Box(Modifier.fillMaxSize().sky()) {
        when (page) {
            Pg.Home -> HomePage { page = it }
            Pg.Menu -> MenuPage({ page = Pg.Home }) { page = it }
            Pg.Hearing -> HearingPage { page = Pg.Menu }
            Pg.Commands -> CommandsPage({ page = Pg.Menu }) { editing = it; page = Pg.Edit }
            Pg.Edit -> EditPage(editing) { page = Pg.Commands }
            Pg.Look -> LookPage({ page = Pg.Menu }) { calibBack = Pg.Look; page = Pg.Calibrate }
            Pg.Safety -> SafetyPage { page = Pg.Menu }
            Pg.Vocab -> VocabPage { page = Pg.Menu }
            Pg.Try -> TryPage { page = Pg.Menu }
            Pg.Setup -> SetupPage({ Store.put("setupdone", true); page = Pg.Home }) { calibBack = Pg.Setup; page = Pg.Calibrate }
            Pg.Calibrate -> CalibratePage { page = calibBack }
            Pg.Train -> TrainPage { page = Pg.Menu }
            Pg.Mine -> VoiceLockPage { page = Pg.Menu }
            Pg.Talk -> TalkPage { page = Pg.Menu }
            Pg.Voice -> VoicePage { page = Pg.Menu }
            Pg.Lately -> LatelyPage { page = Pg.Menu }
        }
    }
}

@Composable
fun HomePage(go: (Pg) -> Unit) {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var bump by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        bump++
        if (has(ctx, Manifest.permission.RECORD_AUDIO) && !Buddy.micOn) MicService.start(ctx)
    }
    val mic = remember(tick, bump) { has(ctx, Manifest.permission.RECORD_AUDIO) }
    val acc = remember(tick, bump) { accOn(ctx) }
    val bat = remember(tick, bump) { batOk(ctx) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Tx("Wave", 22, weight = FontWeight.Medium)
                Tx(if (Buddy.micOn && !Buddy.sleeping) "Online" else if (Buddy.sleeping) "Resting" else "Offline", 12,
                    if (Buddy.micOn && !Buddy.sleeping) Coral else Mute, FontWeight.Normal)
            }
            Box {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).clickable { go(Pg.Menu) },
                    contentAlignment = Alignment.Center
                ) { Tx("\u22EE", 24, Ink) }
            }
        }

        Spacer(Modifier.weight(0.4f))
        JarvisCore(Modifier.fillMaxWidth(0.92f).aspectRatio(1f))
        Spacer(Modifier.height(10.dp))
        Tx(Buddy.status, 15, if (Buddy.micOn && !Buddy.sleeping) Ink else Mute, FontWeight.Medium, maxLines = 2)
        if (Buddy.modeName.isNotEmpty()) Tx(Buddy.modeName, 13, Coral, FontWeight.Normal)
        Spacer(Modifier.height(8.dp))
        // live captions: what I'm hearing, then what I said back
        Column(Modifier.fillMaxWidth().height(64.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (Buddy.heard.isNotEmpty() && Buddy.micOn) {
                Tx("\u201C" + Buddy.heard + "\u201D", 16, Ink, FontWeight.Normal, maxLines = 2)
            }
            if (Buddy.reply.isNotEmpty() && Buddy.micOn) Tx(Buddy.reply, 13, Coral, FontWeight.Normal, maxLines = 1)
        }
        if (Buddy.modelError.isNotEmpty()) Tx(Buddy.modelError, 12, Bad, FontWeight.Normal, maxLines = 2)
        Spacer(Modifier.weight(0.6f))

        if (!mic || !acc || !bat) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Paper).border(1.dp, Hair, RoundedCornerShape(16.dp))
                    .clickable { go(Pg.Setup) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Tx("A few things still need switching on", 13, Ink, FontWeight.Normal, modifier = Modifier.weight(1f))
                Tx("Fix", 14, Coral)
            }
            Spacer(Modifier.height(12.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn(if (Buddy.micOn) "Stop" else "Start listening", filled = !Buddy.micOn) {
                if (Buddy.micOn) MicService.stop()
                else if (mic) { Buddy.sleeping = false; MicService.start(ctx) }
                else permLauncher.launch(wantedPerms())
            }
            if (Buddy.micOn) Btn(if (Buddy.sleeping) "Wake up" else "Rest") {
                Buddy.sleeping = !Buddy.sleeping
                MicService.refreshGate()
                Hands.inst?.setFabMode()
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun HairLine() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Hair))
}

@Composable
fun Nav(title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Tx(title, 15, weight = FontWeight.Medium)
            Tx(sub, 12, Mute, FontWeight.Normal)
        }
        Tx("›", 22, Mute.copy(alpha = 0.6f))
    }
}
