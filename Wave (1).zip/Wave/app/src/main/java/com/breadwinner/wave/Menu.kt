package com.breadwinner.wave

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Small line icons, drawn in code so they match the Jarvis look and cost nothing in size. */
enum class Ico { MIC, CHAT, EAR, LOCK, SPARK, PALETTE, LIST, BOOK, SHIELD, CLOCK, PLAY, WRENCH }

@Composable
fun IconMark(icon: Ico, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(22.dp)) {
        val u = size.minDimension / 24f
        val st = Stroke(width = 1.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(vararg pts: Float): Path {
            val path = Path()
            path.moveTo(pts[0] * u, pts[1] * u)
            var i = 2
            while (i < pts.size) { path.lineTo(pts[i] * u, pts[i + 1] * u); i += 2 }
            return path
        }
        fun circle(cx: Float, cy: Float, r: Float, fill: Boolean = false) =
            if (fill) drawCircle(tint, r * u, Offset(cx * u, cy * u)) else drawCircle(tint, r * u, Offset(cx * u, cy * u), style = st)
        fun rr(x: Float, y: Float, w: Float, h: Float, r: Float) =
            drawRoundRect(tint, Offset(x * u, y * u), Size(w * u, h * u), CornerRadius(r * u), style = st)
        fun arcs(x: Float, y: Float, w: Float, h: Float, start: Float, sweep: Float) =
            drawArc(tint, start, sweep, false, Offset(x * u, y * u), Size(w * u, h * u), style = st)
        when (icon) {
            Ico.MIC -> { rr(9f, 3f, 6f, 11f, 3f); arcs(5.5f, 6f, 13f, 12f, 0f, 180f); drawPath(p(12f, 18f, 12f, 21f), tint, style = st) }
            Ico.CHAT -> { rr(3f, 4f, 18f, 13f, 4f); drawPath(p(8f, 17f, 7f, 21f, 12f, 17f), tint, style = st) }
            Ico.EAR -> { drawPath(p(3f, 12f, 5f, 12f), tint, style = st); drawPath(p(7f, 8f, 7f, 16f), tint, style = st); drawPath(p(11f, 5f, 11f, 19f), tint, style = st); drawPath(p(15f, 8f, 15f, 16f), tint, style = st); drawPath(p(19f, 10f, 19f, 14f), tint, style = st) }
            Ico.LOCK -> { rr(5f, 10f, 14f, 11f, 2f); arcs(8f, 3f, 8f, 12f, 180f, 180f); drawPath(p(8f, 9f, 8f, 10f), tint, style = st); drawPath(p(16f, 9f, 16f, 10f), tint, style = st); circle(12f, 15.5f, 1.3f, true) }
            Ico.SPARK -> { drawPath(p(12f, 3f, 14f, 10f, 21f, 12f, 14f, 14f, 12f, 21f, 10f, 14f, 3f, 12f, 10f, 10f, 12f, 3f), tint, style = st) }
            Ico.PALETTE -> { circle(12f, 12f, 9f); circle(8.5f, 9f, 1.3f, true); circle(12.5f, 7f, 1.3f, true); circle(16f, 10f, 1.3f, true); circle(15f, 15.5f, 2f) }
            Ico.LIST -> { for (y in listOf(6f, 12f, 18f)) { circle(4.5f, y, 1.2f, true); drawPath(p(8f, y, 20f, y), tint, style = st) } }
            Ico.BOOK -> { drawPath(p(12f, 6f, 12f, 20f), tint, style = st); drawPath(p(12f, 6f, 7f, 4f, 3f, 5f, 3f, 19f, 7f, 18f, 12f, 20f, 17f, 18f, 21f, 19f, 21f, 5f, 17f, 4f, 12f, 6f), tint, style = st) }
            Ico.SHIELD -> { drawPath(p(12f, 3f, 20f, 6f, 20f, 12f, 16f, 18f, 12f, 21f, 8f, 18f, 4f, 12f, 4f, 6f, 12f, 3f), tint, style = st); drawPath(p(8.5f, 12f, 11f, 14.5f, 15.5f, 9.5f), tint, style = st) }
            Ico.CLOCK -> { circle(12f, 12f, 9f); drawPath(p(12f, 7f, 12f, 12f, 15.5f, 14f), tint, style = st) }
            Ico.PLAY -> { circle(12f, 12f, 9f); drawPath(p(10f, 8.5f, 16f, 12f, 10f, 15.5f, 10f, 8.5f), tint, style = st) }
            Ico.WRENCH -> { circle(12f, 12f, 3f); for (i in 0 until 8) { val a = Math.toRadians(i * 45.0); val c = kotlin.math.cos(a).toFloat(); val s = kotlin.math.sin(a).toFloat(); drawPath(p(12f + c * 6f, 12f + s * 6f, 12f + c * 9f, 12f + s * 9f), tint, style = st) } }
        }
    }
}

private class Item(val icon: Ico, val title: String, val sub: String, val page: Pg)
private class Shelf(val name: String, val items: List<Item>)

private val shelves = listOf(
    Shelf("Voice and talking", listOf(
        Item(Ico.MIC, "Voice", "How Wave sounds, what it calls you", Pg.Voice),
        Item(Ico.CHAT, "Small talk", "Replies to hello, how are you, your own lines", Pg.Talk),
    )),
    Shelf("Hearing", listOf(
        Item(Ico.EAR, "Wake and hearing", "Wake words, noise, earbuds mic, music", Pg.Hearing),
        Item(Ico.SPARK, "Train me", "Fix words I got wrong", Pg.Train),
        Item(Ico.LOCK, "Only my voice", "Ignore everyone except you", Pg.Mine),
    )),
    Shelf("Look and feel", listOf(
        Item(Ico.PALETTE, "Look and feel", "Theme, ring, floating words, round button", Pg.Look),
    )),
    Shelf("Commands", listOf(
        Item(Ico.LIST, "Commands", "What you can say", Pg.Commands),
        Item(Ico.BOOK, "My words", "Names, like \"mum\" means Mum Mobile", Pg.Vocab),
    )),
    Shelf("Safety", listOf(
        Item(Ico.SHIELD, "Safety", "Asking first, what Wave may do, secret phrase", Pg.Safety),
    )),
    Shelf("Help", listOf(
        Item(Ico.CLOCK, "Lately", "What I heard and did", Pg.Lately),
        Item(Ico.PLAY, "Try it", "Type a command to test it", Pg.Try),
        Item(Ico.WRENCH, "Setup", "Run the first-time setup again", Pg.Setup),
    )),
)

/** Everything except the home screen, grouped onto shelves, each with its own icon. */
@Composable
fun MenuPage(back: () -> Unit, go: (Pg) -> Unit) {
    Page {
        Header("Menu", "Everything in one place", back)
        for (sh in shelves) {
            Tx(sh.name, 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
            Glass {
                sh.items.forEachIndexed { i, it ->
                    if (i > 0) HairLine()
                    Row(
                        Modifier.fillMaxWidth().clickable { go(it.page) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Peach).border(1.dp, Hair, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) { IconMark(it.icon, Coral) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Tx(it.title, 15, weight = FontWeight.Medium)
                            Tx(it.sub, 12, Mute, FontWeight.Normal, maxLines = 1)
                        }
                        Tx("\u203A", 22, Mute)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

/** Wake words and everything about how Wave hears you. */
@Composable
fun HearingPage(back: () -> Unit) {
    val ctx = LocalContext.current
    Page {
        Header("Wake and hearing", "How Wave hears you", back)
        Glass {
            Tx("Wake word", 16)
            Spacer(Modifier.height(6.dp))
            Tx("I answer to all of these. Pick the one you say most.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            val wakes = listOf("hey wave", "wave buddy", "hey buddy", "poseidon")
            Seg(wakes.map { it.replaceFirstChar { c -> c.uppercase() } }, wakes.indexOf(Store.wake).coerceAtLeast(0)) {
                Store.put("wake", wakes[it]); Ear.rebuildWake(ctx)
            }
            Spacer(Modifier.height(10.dp))
            Tx("How easily I wake", 13)
            Spacer(Modifier.height(6.dp))
            val sens = listOf("easy", "normal", "strict")
            Seg(listOf("Easy", "Normal", "Strict"), sens.indexOf(Store.s("wakesens", "normal")).coerceAtLeast(0)) {
                Store.put("wakesens", sens[it]); Ear.rebuildWake(ctx)
            }
            Tx("Easy wakes on the first try but may wake by mistake. Strict needs a clear wake word.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            Spacer(Modifier.height(10.dp))
            Tx("Background noise cleaner", 13)
            Spacer(Modifier.height(6.dp))
            val cl = listOf("off", "auto", "always")
            Seg(listOf("Off", "Auto", "Always"), cl.indexOf(Store.s("cleaner", "auto")).coerceAtLeast(0)) { Store.put("cleaner", cl[it]) }
            Tx("Auto switches it on by itself when the room gets loud.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            ToggleRow("Phone's noise filter", "Samsung's call filter. Also lets \"Hey Wave\" interrupt me while I talk.", Store.b("phonefilter", true)) {
                Store.put("phonefilter", it); Ear.restart()
            }
            ToggleRow("Use my earbuds' mic", "When earbuds are connected. Music sounds like a phone call while this is on.", Store.b("budsmic", false)) {
                Store.put("budsmic", it); Ear.restart()
            }
            ToggleRow("Lower music while I talk", "Spotify, YouTube and the rest go quiet, then come back.", Store.b("duck", true)) { Store.put("duck", it) }
            SliderRow("Keep listening after a command", Store.stayAwake.toFloat(), 0f..30f, Store.stayAwake.toString() + " s") { Store.put("stay", it.toInt()) }
        }
    }
}
