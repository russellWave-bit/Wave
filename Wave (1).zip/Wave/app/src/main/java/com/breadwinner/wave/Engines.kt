package com.breadwinner.wave

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.io.SequenceInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Collections
import java.util.zip.ZipInputStream

/**
 * The engine pack: Wave's hearing, voice and voice-ID files (about 1 GB).
 * They aren't inside the app. Wave downloads them once from the "engines" release
 * of its own GitHub repo, in parts that resume if the download stops, then keeps them.
 * App updates after that are small, and the engines stay.
 */
object Engines {
    /** Bump this when the engines change; Wave then fetches the new pack. */
    const val VERSION = "1"
    private const val TAG = "engines-v1"

    enum class Stage { IDLE, CHECKING, DOWNLOADING, VERIFYING, UNPACKING, READY, ERROR }

    var stage by mutableStateOf(Stage.IDLE)
    var done by mutableLongStateOf(0L)
    var total by mutableLongStateOf(0L)
    var part by mutableStateOf("")
    var message by mutableStateOf("")
    var installed by mutableStateOf(false)

    @Volatile private var stopAsked = false
    private var dir: File? = null

    private fun base(c: Context): String = "https://github.com/" + BuildConfig.WAVE_REPO + "/releases/download/" + TAG + "/"

    fun dir(c: Context): File = dir ?: File(c.filesDir, "engines").also { dir = it }
    private fun packDir(c: Context): File = File(c.filesDir, "pack").also { it.mkdirs() }

    /** Where an engine file lives on the phone. */
    fun path(rel: String): String = File(dir ?: File("/"), rel).absolutePath

    fun has(rel: String): Boolean = dir?.let { File(it, rel).isFile } ?: false

    /** Called at app start: works out whether the engines are here. */
    fun check(c: Context) {
        val d = dir(c)
        installed = File(d, ".version").let { it.isFile && it.readText().trim() == VERSION }
        if (installed) stage = Stage.READY
    }

    /** Puts files that ship inside the app (like the wake words) next to the engines. */
    fun prepare(c: Context) {
        val d = dir(c)
        try {
            File(d, "kws").mkdirs()
            c.assets.open("kws/keywords.txt").use { i -> FileOutputStream(File(d, "kws/keywords.txt")).use { o -> i.copyTo(o) } }
        } catch (e: Exception) { }
    }

    fun onWifi(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    fun online(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun start(c: Context) {
        if (stage == Stage.DOWNLOADING || stage == Stage.UNPACKING || stage == Stage.VERIFYING || stage == Stage.CHECKING) return
        stopAsked = false
        ContextCompat.startForegroundService(c, Intent(c, EngineService::class.java))
    }

    fun pause() { stopAsked = true }

    /** Bytes already on the phone, so the bar shows real progress even after a restart. */
    fun bytesSoFar(c: Context): Long = packDir(c).listFiles()?.sumOf { it.length() } ?: 0L

    /** Opens a link, following GitHub's hop to its file servers, asking for the bytes from [from] onwards. */
    private fun open(url: String, from: Long): HttpURLConnection {
        var u = url
        repeat(6) {
            val con = URL(u).openConnection() as HttpURLConnection
            con.instanceFollowRedirects = false
            con.connectTimeout = 20000
            con.readTimeout = 30000
            con.setRequestProperty("User-Agent", "Wave-Android")
            if (from > 0) con.setRequestProperty("Range", "bytes=$from-")
            val code = con.responseCode
            if (code in 300..399) {
                u = con.getHeaderField("Location") ?: throw Exception("Bad redirect")
                con.disconnect()
            } else return con
        }
        throw Exception("Too many redirects")
    }

    private fun readText(url: String): String {
        val con = open(url, 0)
        if (con.responseCode != 200) throw Exception("HTTP " + con.responseCode)
        return con.inputStream.bufferedReader().use { it.readText() }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** The whole job. Runs on a background thread inside EngineService. */
    fun run(c: Context, progress: (String) -> Unit) {
        try {
            stage = Stage.CHECKING
            message = "Checking the engine pack…"
            if (!online(c)) throw Exception("No internet. Connect to Wi-Fi and tap Continue.")
            if (Store.b("wifionly", true) && !onWifi(c)) throw Exception("You're on mobile data. Connect to Wi-Fi, or switch off \"Wi-Fi only\".")
            val manifest = JSONObject(readText(base(c) + "manifest.json"))
            val parts = manifest.getJSONArray("parts")
            total = manifest.getLong("total")
            val need = total * 2 + 200L * 1024 * 1024
            val free = StatFs(c.filesDir.absolutePath).availableBytes + bytesSoFar(c)
            if (free < need) throw Exception("Not enough space. Wave needs about " + (need / 1_000_000_000.0).let { "%.1f".format(it) } + " GB free.")

            // 1. download each part, carrying on from wherever it stopped
            stage = Stage.DOWNLOADING
            val files = ArrayList<File>()
            var before = 0L
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                val name = p.getString("name")
                val size = p.getLong("size")
                val f = File(packDir(c), name)
                files.add(f)
                part = "Part " + (i + 1) + " of " + parts.length()
                if (f.length() > size) f.delete()
                while (f.length() < size) {
                    if (stopAsked) throw InterruptedException()
                    val con = open(base(c) + name, f.length())
                    val code = con.responseCode
                    if (code != 200 && code != 206) throw Exception("Download failed (HTTP $code). Tap Continue to try again.")
                    if (code == 200 && f.length() > 0) f.delete()   // server ignored the resume: start this part again
                    RandomAccessFile(f, "rw").use { out ->
                        out.seek(f.length())
                        con.inputStream.use { inp ->
                            val buf = ByteArray(256 * 1024)
                            var lastUi = 0L
                            while (true) {
                                if (stopAsked) throw InterruptedException()
                                val n = inp.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                val now = System.currentTimeMillis()
                                if (now - lastUi > 400) {
                                    lastUi = now
                                    done = before + out.length()
                                    message = "Downloading"
                                    progress(part + " · " + mb(done) + " of " + mb(total))
                                }
                            }
                        }
                    }
                    con.disconnect()
                }
                // 2. check the part arrived whole; if not, fetch only this part again
                stage = Stage.VERIFYING
                message = "Checking " + part.lowercase() + "…"
                val want = p.optString("sha256", "")
                if (want.isNotEmpty() && sha256(f) != want) {
                    f.delete()
                    throw Exception("A part arrived damaged and was removed. Tap Continue to fetch it again.")
                }
                stage = Stage.DOWNLOADING
                before += size
                done = before
            }

            // 3. unpack everything into Wave's storage
            stage = Stage.UNPACKING
            message = "Unpacking the engines…"
            progress("Unpacking")
            val tmp = File(c.filesDir, "engines.tmp")
            tmp.deleteRecursively()
            tmp.mkdirs()
            val streams: List<InputStream> = files.map { it.inputStream().buffered(1 shl 20) }
            ZipInputStream(SequenceInputStream(Collections.enumeration(streams))).use { z ->
                var e = z.nextEntry
                val root = tmp.canonicalPath
                while (e != null) {
                    val out = File(tmp, e.name)
                    if (!out.canonicalPath.startsWith(root)) throw Exception("Bad file in the pack")
                    if (e.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { o -> z.copyTo(o, 1 shl 20) }
                    }
                    e = z.nextEntry
                }
            }
            File(tmp, ".version").writeText(VERSION)
            val d = dir(c)
            d.deleteRecursively()
            if (!tmp.renameTo(d)) throw Exception("Couldn't finish setting up the engines.")
            packDir(c).deleteRecursively()
            prepare(c)
            installed = true
            stage = Stage.READY
            message = "Engines ready."
            progress("Ready")
        } catch (e: InterruptedException) {
            stage = Stage.IDLE
            message = "Paused. Tap Continue to carry on from " + mb(bytesSoFar(c)) + "."
        } catch (e: Exception) {
            stage = Stage.ERROR
            message = e.message ?: "Something went wrong. Tap Continue to try again."
        }
    }

    fun mb(b: Long): String = if (b >= 1_000_000_000) "%.2f GB".format(b / 1_000_000_000.0) else "%d MB".format(b / 1_000_000)
}

/** Keeps the download going while you use other apps, with a progress notification. */
class EngineService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel("engines") == null) {
            nm.createNotificationChannel(NotificationChannel("engines", "Downloading Wave's engines", NotificationManager.IMPORTANCE_LOW))
        }
        fun note(text: String): Notification = NotificationCompat.Builder(this, "engines")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Wave is getting its engines")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(1000, if (Engines.total > 0) (Engines.done * 1000 / Engines.total).toInt() else 0, Engines.total == 0L)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, note("Starting…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(2, note("Starting…"))
        Thread {
            Engines.run(applicationContext) { t -> nm.notify(2, note(t)) }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            if (Engines.installed && Store.b("listening", false)) MicService.start(applicationContext)
        }.start()
        return START_NOT_STICKY
    }
}

/** The first screen until the engines are on the phone. */
@Composable
fun EnginePage() {
    val ctx = LocalContext.current
    val busy = Engines.stage == Engines.Stage.CHECKING || Engines.stage == Engines.Stage.DOWNLOADING ||
        Engines.stage == Engines.Stage.VERIFYING || Engines.stage == Engines.Stage.UNPACKING
    val have = Engines.bytesSoFar(ctx)
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(0.3f))
        JarvisCore(Modifier.fillMaxWidth(0.7f).aspectRatio(1f))
        Spacer(Modifier.height(16.dp))
        Tx(if (Engines.installed) "Engines ready" else "Wave needs its engines", 22, weight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Tx(
            "A one-time download of about 1 GB: hearing, voice and voice-ID. After this, Wave runs offline and app updates are small.",
            14, Mute, FontWeight.Normal
        )
        Spacer(Modifier.height(20.dp))

        // progress
        val frac = if (Engines.total > 0) (Engines.done.toFloat() / Engines.total).coerceIn(0f, 1f) else 0f
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Peach)) {
            Box(Modifier.fillMaxWidth(if (Engines.stage == Engines.Stage.UNPACKING || Engines.installed) 1f else frac).fillMaxHeight().clip(RoundedCornerShape(50)).background(Coral))
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Tx(
                when {
                    Engines.installed -> "Done"
                    Engines.total > 0 -> Engines.part.ifEmpty { "Downloaded" } + " · " + Engines.mb(Engines.done) + " of " + Engines.mb(Engines.total)
                    have > 0 -> Engines.mb(have) + " already downloaded"
                    else -> "Not started"
                },
                12, Mute, FontWeight.Normal, modifier = Modifier.weight(1f)
            )
            if (Engines.total > 0 && !Engines.installed) Tx((frac * 100).toInt().toString() + "%", 12, Coral)
        }
        if (Engines.message.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Tx(Engines.message, 13, if (Engines.stage == Engines.Stage.ERROR) Bad else Ink, FontWeight.Normal)
        }
        Spacer(Modifier.height(16.dp))
        ToggleRow("Wi-Fi only", "Never use mobile data for this", Store.b("wifionly", true)) { Store.put("wifionly", it) }
        Spacer(Modifier.weight(0.7f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (busy) Btn("Pause") { Engines.pause() }
            else Btn(if (have > 0 || Engines.stage == Engines.Stage.ERROR) "Continue" else "Download engines", filled = true) { Engines.start(ctx) }
        }
    }
}
