package com.breadwinner.wave

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

/** Does the steps one by one and says in plain words why one failed. */
object Runner {
    @Volatile private var gen = 0
    private var torchOn = false

    fun stopAll() { gen++ }

    private fun powerOf(t: String): String = when (t) {
        "OPEN_APP", "OPEN_URL", "WA_CHAT" -> "apps"
        "TAP_TEXT", "LONG_TEXT", "TAP_ID", "TAP_NUM", "LONG_NUM", "TAP_XY", "BACK", "HOME", "RECENTS", "NOTIFS", "QUICK",
        "LOCK", "SHOT", "POWER", "SCROLL", "SWIPE", "SCROLL_SPEED", "NUMS_ON", "NUMS_OFF", "GRID_ON", "GRID_OFF", "GRID_UP",
        "GRID_PICK", "GRID_TAP", "GRID_LONG", "GRID_GRAB", "GRID_DROP" -> "taps"
        "TYPE", "SEND", "UNDO_TYPE", "CLEAR_TEXT", "DICTATE_ON", "DICTATE_OFF" -> "typing"
        "CALL", "SPEAKER" -> "calls"
        else -> "system"
    }

    private fun powerName(p: String): String = when (p) {
        "apps" -> "Opening apps"
        "taps" -> "Tapping and swiping"
        "typing" -> "Typing"
        "calls" -> "Calling"
        else -> "Phone controls"
    }

    suspend fun run(p: Plan): String? {
        val my = ++gen
        for (s in p.steps) {
            val pw = powerOf(s.type)
            if (!Store.power(pw)) return powerName(pw) + " is switched off in Safety."
        }
        for (s in p.steps) {
            if (gen != my && s.type != "CANCEL") return "Stopped."
            val f = exec(s)
            if (f != null) return f
        }
        return null
    }

    private const val NEED_HANDS = "Switch on Wave Hands first. It's in Accessibility settings."

    private fun launch(i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            (Hands.inst as? Context ?: Store.app).startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun exec(s: Step): String? {
        val h = Hands.inst
        val ctx = Store.app
        when (s.type) {
            "WAIT" -> delay(s.n.toLong())
            "OPEN_APP" -> {
                var pkg = Apps.all().firstOrNull { it.pkg == s.a }?.pkg
                if (pkg == null) {
                    val hit = Apps.find(s.a)
                    if (hit != null && hit.second >= 0.6f) pkg = hit.first.pkg
                }
                if (pkg == null) return "I couldn't find an app called \"${s.a}\"."
                val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "That app can't be opened."
                if (!launch(i)) return "I couldn't open it. Android may be blocking it right now."
            }
            "OPEN_URL" -> if (!launch(Intent(Intent.ACTION_VIEW, Uri.parse(s.a)))) return "I couldn't open that link."
            "WA_CHAT" -> {
                val said = s.a.trim()
                val digitsOnly = said.filter { it.isDigit() }
                var num = ""
                if (digitsOnly.length >= 7) num = Contacts.waNumber(said)
                else {
                    if (!Contacts.granted()) return "I need permission to read your contacts."
                    val hit = Contacts.find(said)
                    if (hit == null || hit.second < 0.62f) return "I couldn't find \"$said\" in your contacts."
                    num = Contacts.waNumber(hit.first.numbers.first())
                }
                if (num.length < 7) return "That contact has no usable number."
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num"))
                var pkg: String? = null
                for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                    try { ctx.packageManager.getPackageInfo(p, 0); pkg = p; break } catch (e: Exception) { }
                }
                if (pkg == null) return "WhatsApp isn't installed."
                i.setPackage(pkg)
                if (!launch(i)) return "I couldn't open WhatsApp."
            }
            "CALL" -> {
                var num = s.a
                if (s.a.filter { it.isDigit() }.length < 5) {
                    if (!Contacts.granted()) return "I need permission to read your contacts."
                    val hit = Contacts.find(s.a)
                    if (hit == null || hit.second < 0.62f) return "I couldn't find \"${s.a}\" in your contacts."
                    num = hit.first.numbers.first()
                }
                val can = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                val uri = Uri.parse("tel:" + Uri.encode(num))
                if (!launch(Intent(if (can) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))) return "I couldn't start the call."
            }
            "SPEAKER" -> {
                delay(1800)
                val ok = h != null && h.tapText("Speaker|Speakerphone", false, 1500)
                if (!ok) {
                    try {
                        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        am.isSpeakerphoneOn = true
                    } catch (e: Exception) {
                        return "I couldn't turn the speaker on."
                    }
                }
            }
            "TIMER" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s.n).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                if (s.a.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, s.a)
                if (!launch(i)) return "I couldn't set the timer."
            }
            "ALARM" -> {
                val p = s.a.split(":")
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, p[0].toInt()).putExtra(AlarmClock.EXTRA_MINUTES, p[1].toInt())
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                if (!launch(i)) return "I couldn't set the alarm."
            }
            "TORCH" -> {
                try {
                    val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    var id: String? = null
                    for (c in cm.cameraIdList) {
                        if (cm.getCameraCharacteristics(c).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) { id = c; break }
                    }
                    if (id == null) return "This phone has no flashlight."
                    torchOn = when (s.a) { "on" -> true; "off" -> false; else -> !torchOn }
                    cm.setTorchMode(id, torchOn)
                } catch (e: Exception) {
                    return "I couldn't use the flashlight."
                }
            }
            "MEDIA" -> {
                // play, pause, next and previous for whatever music app is playing
                try {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val code = when (s.a) {
                        "play" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
                        "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
                        "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
                        "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
                        else -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                    }
                    am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
                    am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
                } catch (e: Exception) {
                    return "I couldn't control the music."
                }
            }
            "VOLUME" -> {
                try {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val dir = when (s.a) {
                        "up" -> AudioManager.ADJUST_RAISE
                        "down" -> AudioManager.ADJUST_LOWER
                        "mute" -> AudioManager.ADJUST_MUTE
                        else -> AudioManager.ADJUST_UNMUTE
                    }
                    val times = if (s.a == "up" || s.a == "down") 2 else 1
                    for (k in 1..times) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, if (k == times) AudioManager.FLAG_SHOW_UI else 0)
                } catch (e: Exception) {
                    return "I couldn't change the volume."
                }
            }
            "PANEL" -> {
                val i = if (s.a == "bluetooth") Intent(Settings.ACTION_BLUETOOTH_SETTINGS) else Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                if (!launch(i)) return "I couldn't open that."
            }
            "WORDS" -> Fx.words(s.a, "", 1600)
            "HELP" -> Fx.words("Try saying…", Parser.helpLines.joinToString("\n"), 6000)
            "SLEEP" -> Brain.sleep()
            "CANCEL" -> { stopAll(); Brain.cancel() }
            "TEACH" -> Brain.startTeach()
            "DICTATE_ON" -> Brain.startDictation()
            "DICTATE_OFF" -> Brain.endDictation()
            "SCROLL_SPEED" -> {
                val f = Store.f("scrollf", 1f)
                Store.put("scrollf", if (s.a == "faster") minOf(2.5f, f * 1.4f) else maxOf(0.4f, f / 1.4f))
            }
            else -> {
                // everything below needs the Accessibility hands
                if (h == null) return NEED_HANDS
                when (s.type) {
                    "TAP_TEXT" -> if (!h.tapText(s.a, false, 3200)) return "I couldn't find \"${s.a.substringBefore("|")}\" on the screen."
                    "LONG_TEXT" -> if (!h.tapText(s.a, true, 3200)) return "I couldn't find \"${s.a}\" on the screen."
                    "TAP_ID" -> if (!h.tapId(s.a, 3200)) return "I couldn't find that button."
                    "TAP_NUM" -> if (!h.tapNum(s.n, false)) return if (h.numbersOn) "I don't see number ${s.n}." else "Say \"show numbers\" first."
                    "LONG_NUM" -> if (!h.tapNum(s.n, true)) return if (h.numbersOn) "I don't see number ${s.n}." else "Say \"show numbers\" first."
                    "TAP_XY" -> {
                        val p = s.a.split(",")
                        h.tapAt(p[0].toFloat() * h.screenW, p[1].toFloat() * h.screenH, false)
                    }
                    "TYPE" -> if (!h.typeText(s.a)) return "I couldn't find a box to type in."
                    "SEND" -> if (!h.sendIt()) return "I couldn't find a Send button."
                    "UNDO_TYPE" -> if (!h.undoType()) return "There's nothing to undo."
                    "CLEAR_TEXT" -> if (!h.clearText()) return "I couldn't find a text box."
                    "BACK" -> h.global(AccessibilityService.GLOBAL_ACTION_BACK)
                    "HOME" -> h.global(AccessibilityService.GLOBAL_ACTION_HOME)
                    "RECENTS" -> h.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
                    "NOTIFS" -> h.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                    "QUICK" -> h.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
                    "LOCK" -> h.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                    "SHOT" -> h.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                    "POWER" -> h.global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
                    "SCROLL", "SWIPE" -> if (!h.scroll(s.a)) return "There's nothing to scroll here."
                    "NUMS_ON" -> {
                        val n = h.setNumbers(true)
                        if (n == 0) return "I don't see anything to tap here."
                    }
                    "NUMS_OFF" -> h.setNumbers(false)
                    "GRID_ON" -> h.gridOpen()
                    "GRID_OFF" -> h.gridClose()
                    "GRID_UP" -> h.gridUp()
                    "GRID_PICK" -> h.gridPick(s.n)?.let { return it }
                    "GRID_TAP" -> h.gridTap(false)?.let { return it }
                    "GRID_LONG" -> h.gridTap(true)?.let { return it }
                    "GRID_GRAB" -> h.gridGrab()?.let { return it }
                    "GRID_DROP" -> h.gridDrop()?.let { return it }
                    "READ_SCREEN" -> {
                        val t = h.screenText()
                        if (t.isBlank()) return "I can't see any words on this screen."
                        Fx.words(t.take(220), "", 6000)
                        Voice.say(t.take(400))
                    }
                    else -> return "I don't know the step \"${s.type}\"."
                }
            }
        }
        return null
    }
}
