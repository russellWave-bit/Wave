package com.breadwinner.wave

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The eye: Wave's face on the screen, over every app. It replaces the floating words.
 * There are two looks: the Poseidon octopus (a 3D page that EyeBox lays over this view) and the flat Jarvis eye drawn here.
 * It opens when Wave hears you, moves while it thinks, pulses while it speaks, and closes when done.
 * A small caption can sit under it. "Poseidon, I summon you" holds it open big, until you say close.
 */
class EyeView(ctx: Context) : View(ctx) {
    private val dm = resources.displayMetrics
    private fun dp(v: Float) = v * dm.density
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, dm)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val tps = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private var layMain: StaticLayout? = null
    private var laySub: StaticLayout? = null
    private var layKey = ""

    private var a = 0f                    // how visible, 0 to 1
    private var lastNs = 0L
    private var t = 0f
    private var spin = 0f
    private var shownUntil = 0L
    private var capText = ""
    private var capSub = ""
    private var capUntil = 0L
    private var summonUntil = 0L
    private var nextBlink = 2.5f
    private var blinkT0 = -10f
    var summoned = false
        private set
    var onGone: (() -> Unit)? = null

    /** Preview mode: the settings page shows the eye in a small box, always on. Tap to change what it is doing. */
    var preview = false
    private var previewState = 0
    private val lab = Paint(Paint.ANTI_ALIAS_FLAG)

    /** The box that holds this view and the octopus page. */
    var host: EyeBox? = null

    /** Live mode: fills its box like the preview, but follows what Wave is really doing (the home screen). */
    var live = false
    private var lingerUntil = 0L
    private var wasWant = false
    private var wasBig = false

    /** Keep the eye open for a while (while Wave hears, thinks or finishes). */
    fun keep(ms: Long) {
        shownUntil = max(shownUntil, System.currentTimeMillis() + ms)
        invalidate()
    }

    /** Let it close soon, unless a caption or summon is holding it. */
    fun idle() {
        shownUntil = min(shownUntil, System.currentTimeMillis() + 350)
    }

    fun caption(text: String, sub: String, ms: Int) {
        capText = text
        capSub = sub
        capUntil = System.currentTimeMillis() + ms
        invalidate()
    }

    fun summon() {
        summoned = true
        summonUntil = System.currentTimeMillis() + Store.i("eyestay", 20) * 1000L
        invalidate()
    }

    fun close() {
        summoned = false
        shownUntil = 0L
        capUntil = 0L
        Brain.releaseAwake()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (preview) {
            if (live) return false
            if (e.actionMasked == MotionEvent.ACTION_DOWN) previewState = (previewState + 1) % 4
            return true
        }
        if (summoned && Store.b("eyetap", true) && e.actionMasked == MotionEvent.ACTION_DOWN) {
            Hands.inst?.eyeClose()
            return true
        }
        return false
    }

    private fun textW(l: StaticLayout?): Float {
        if (l == null) return 0f
        var m = 0f
        for (i in 0 until l.lineCount) m = max(m, l.getLineWidth(i))
        return m
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        val ns = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((ns - lastNs) / 1e9f).coerceIn(0f, 0.1f)
        lastNs = ns
        t += dt
        val demo = preview && !live
        val ph = if (demo) (when (previewState) { 1 -> RingState.LISTEN; 2 -> RingState.THINK; else -> RingState.IDLE }) else Buddy.phase
        val speakingNow = Speaker.busy() || (demo && previewState == 3)
        val earLevel = if (demo) 0.35f + 0.5f * kotlin.math.abs(sin(t * 7f) * sin(t * 2.3f)) else Ear.level
        spin += dt * Store.f("eyespeed", 1f) * when (ph) {
            RingState.THINK -> 3.2f
            RingState.LISTEN, RingState.HEAR -> 1.5f
            RingState.DONE -> 1.0f
            RingState.PROBLEM -> 0.3f
            else -> 0.6f
        }
        if (summoned && now > summonUntil) { summoned = false; Brain.releaseAwake() }
        val wantRaw = preview || summoned || now < shownUntil || now < capUntil
        val octo = Store.s("eyestyle", "octopus") != "jarvis" && host?.canShow() == true
        // when the octopus leaves by coming apart, hold the picture until the parts have gone
        if (octo && wasWant && !wantRaw && wasBig && Store.s("octoexit", "fade") == "disassemble") lingerUntil = now + 1500
        if (wantRaw) lingerUntil = 0L
        wasWant = wantRaw
        val want = wantRaw || now < lingerUntil
        val rate = if (Store.b("eyeslow", false)) 1.3f else 4f
        a += ((if (want) 1f else 0f) - a) * min(1f, dt * rate)
        if (!want && a < 0.03f) {
            a = 0f
            lastNs = 0L
            wasBig = false
            host?.rest()
            onGone?.invoke()
            return
        }

        val base = Colours.load("c_eye")?.rgb() ?: 0xFF3FD0FF.toInt()
        val acc = when (ph) {
            RingState.PROBLEM -> 0xFFFF5C6C.toInt()
            RingState.THINK -> 0xFF8FD8FF.toInt()
            else -> base
        }
        val sec = 0xFFA78BFA.toInt()
        val oa = Colours.eyeAlpha()
        fun col(rgb: Int, al: Float): Int = (rgb and 0x00FFFFFF) or ((al * a * oa * 255f).toInt().coerceIn(0, 255) shl 24)

        val w = width.toFloat()
        val h = height.toFloat()
        val big = (summoned || now < lingerUntil) && !preview
        wasBig = summoned && !preview
        val frac = if (big) Store.f("eyesumsize", 0.9f) else Store.f("eyesize", 0.42f)
        val e = a * a * (3f - 2f * a)
        val rFull = if (preview) min(w, h) * 0.42f else frac * w / 2f
        val r = if (preview || octo) rFull else rFull * (0.86f + 0.14f * e)
        val cx = w / 2f
        val cy = if (preview) (if (octo) h * 0.5f else h * 0.46f) else if (big) h * 0.42f else Store.f("eyey", 0.25f) * h
        val px = dm.density
        val style = "jarvis"

        if (big) {
            paint.shader = null
            paint.style = Paint.Style.FILL
            paint.color = if (octo) 0xFF0B0E11.toInt() else 0xFF030A14.toInt()
            paint.alpha = (255f * Store.f("eyedim", 0.8f) * a).toInt().coerceIn(0, 255)
            c.drawRect(0f, 0f, w, h, paint)
        }

        if (demo) {
            c.clipRect(0f, 0f, w, h)
            paint.style = Paint.Style.FILL
            if (octo) {
                // the white studio the octopus was designed in
                paint.shader = RadialGradient(cx, h * 0.44f, max(w, h) * 0.7f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFF4F5F5.toInt(), 0xFFE3E6E8.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                c.drawRoundRect(0f, 0f, w, h, 12f, 12f, paint)
                paint.shader = null
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dm.density
                paint.color = 0xFFC7CDD1.toInt()
                c.drawRoundRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, 12f, 12f, paint)
            } else {
                paint.shader = null
                paint.color = 0xFF030912.toInt()
                c.drawRoundRect(0f, 0f, w, h, 36f, 36f, paint)
            }
        }
        // Wave's own home screen already shows the octopus, so over it only the caption is drawn
        val quiet = EyeBox.liveUp && !preview && !summoned && now >= lingerUntil
        if (quiet) {
            host?.hideOcto()
        } else if (octo) {
            val st = if (speakingNow) 3 else when (ph) {
                RingState.THINK -> 2
                RingState.HEAR, RingState.LISTEN -> 1
                else -> if (Buddy.sleeping && !summoned && !demo) 4 else 0
            }
            host?.frame(cx, cy, rFull, a, wantRaw, big, st, if (st == 1) earLevel else 0f)
        } else {
        host?.hideOcto()
        // soft glow
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r, col(acc, 0.28f), 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint)
        paint.shader = null

        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND

        if (style == "jarvis" || style == "rings") {
            paint.strokeWidth = px
            paint.color = col(acc, 0.25f)
            c.drawCircle(cx, cy, r * 0.97f, paint)
            paint.strokeWidth = 2f * px
            paint.color = col(acc, 0.5f)
            box.set(cx - r * 0.9f, cy - r * 0.9f, cx + r * 0.9f, cy + r * 0.9f)
            for (i in 0 until 24) c.drawArc(box, -spin * 8f + i * 15f, 9f, false, paint)
        }
        if (style == "jarvis") {
            for (i in 0 until 72) {
                val ang = ((i * 5f + spin * 4f) * PI / 180f).toFloat()
                val long = i % 6 == 0
                val r1 = r * 0.8f
                val r2 = r1 - (if (long) 9f else 4f) * px
                paint.strokeWidth = if (long) 2f * px else px
                paint.color = col(acc, if (long) 0.8f else 0.4f)
                c.drawLine(cx + cos(ang) * r1, cy + sin(ang) * r1, cx + cos(ang) * r2, cy + sin(ang) * r2, paint)
            }
        }
        if (style == "jarvis" || style == "rings") {
            paint.strokeWidth = 5f * px
            box.set(cx - r * 0.68f, cy - r * 0.68f, cx + r * 0.68f, cy + r * 0.68f)
            val big3 = spin * 22f
            paint.color = col(acc, 0.95f); c.drawArc(box, big3, 80f, false, paint)
            paint.color = col(acc, 0.7f); c.drawArc(box, big3 + 140f, 50f, false, paint)
            paint.color = col(sec, 0.8f); c.drawArc(box, big3 + 250f, 28f, false, paint)
        }
        if (style == "minimal") {
            paint.strokeWidth = 2f * px
            paint.color = col(acc, 0.6f)
            c.drawCircle(cx, cy, r * 0.62f, paint)
        }
        if (ph == RingState.THINK && style != "minimal") {
            paint.strokeWidth = 3f * px
            paint.color = col(acc, 1f)
            box.set(cx - r * 0.58f, cy - r * 0.58f, cx + r * 0.58f, cy + r * 0.58f)
            c.drawArc(box, spin * 70f, 28f, false, paint)
            c.drawArc(box, spin * 70f + 180f, 28f, false, paint)
        }
        if (style == "rings") {
            paint.strokeWidth = 6f * px
            paint.color = col(acc, 0.85f)
            box.set(cx - r * 0.25f, cy - r * 0.25f, cx + r * 0.25f, cy + r * 0.25f)
            for (i in 0 until 10) c.drawArc(box, -spin * 12f + i * 36f, 24f, false, paint)
        }

        // blink
        var blink = 0f
        if (Store.b("eyeblink", true)) {
            if (t > nextBlink) { blinkT0 = t; nextBlink = t + 3.5f + 2.5f * ((t * 7.3f) % 1f) }
            val bt = t - blinkT0
            if (bt in 0f..0.22f) blink = sin(bt / 0.22f * PI.toFloat())
        }
        val listening = ph == RingState.HEAR || ph == RingState.LISTEN
        val level = if (listening) earLevel else 0f

        c.save()
        c.scale(1f, 1f - blink * 0.9f, cx, cy)
        if (style == "jarvis" || style == "iris" || style == "minimal") {
            if (style != "minimal") {
                paint.strokeWidth = 1.5f * px
                for (i in 0 until 60) {
                    val ang = ((i * 6f + spin * 6f) * PI / 180f).toFloat()
                    val r1 = r * 0.30f
                    val r2 = r * (0.5f + 0.035f * sin(i * 1.7f + t * 2f)) + level * r * 0.1f * (0.5f + 0.5f * sin(i * 0.7f + t * 6f))
                    paint.color = col(acc, 0.55f)
                    c.drawLine(cx + cos(ang) * r1, cy + sin(ang) * r1, cx + cos(ang) * r2, cy + sin(ang) * r2, paint)
                }
                paint.strokeWidth = 2f * px
                paint.color = col(acc, 0.9f)
                c.drawCircle(cx, cy, r * 0.52f, paint)
                paint.strokeWidth = px
                paint.color = col(acc, 0.6f)
                c.drawCircle(cx, cy, r * 0.30f, paint)
            }
        }
        val speaking = speakingNow
        val pr = r * 0.17f * (1f + 0.08f * sin(t * 2.2f) + (if (speaking) 0.14f * sin(t * 13f) else 0f) + level * 0.25f)
        val wander = Store.b("eyewander", true) && (ph == RingState.IDLE || ph == RingState.DONE)
        val ox = if (wander) r * 0.07f * sin(t * 0.9f) else 0f
        val oy = if (wander) r * 0.04f * cos(t * 0.7f) else 0f
        paint.style = Paint.Style.FILL
        paint.color = col(0xFF02101C.toInt(), 1f)
        c.drawCircle(cx + ox, cy + oy, pr, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.5f * px
        paint.color = col(acc, 0.95f)
        c.drawCircle(cx + ox, cy + oy, pr, paint)
        paint.style = Paint.Style.FILL
        paint.color = col(0xFFFFFFFF.toInt(), 0.75f)
        c.drawCircle(cx + ox - pr * 0.35f, cy + oy - pr * 0.35f, pr * 0.18f, paint)
        c.restore()
        }

        // the small caption under the eye
        if (!summoned && Store.b("eyecap", true) && capText.isNotEmpty() && now < capUntil) {
            val maxW = (w * 0.8f).toInt()
            val size = Store.i("eyecapsize", 15)
            val key = "$capText|$capSub|$size|$maxW"
            if (key != layKey) {
                layKey = key
                tp.textSize = sp(size.toFloat())
                tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                layMain = StaticLayout.Builder.obtain(capText, 0, capText.length, tp, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).build()
                tps.textSize = sp(size * 0.82f)
                tps.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                laySub = if (capSub.isNotEmpty()) StaticLayout.Builder.obtain(capSub, 0, capSub.length, tps, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).build() else null
            }
            val lm = layMain
            if (lm != null) {
                val ls = laySub
                val ca = (255f * a * Colours.overlayAlpha()).toInt().coerceIn(0, 255)
                val rgb = Colours.overlayRgb() and 0x00FFFFFF
                tp.color = rgb or (ca shl 24)
                tps.color = rgb or ((ca * 0.85f).toInt() shl 24)
                val bw = max(textW(lm), textW(ls)) + dp(28f)
                val gap = if (ls != null) dp(2f) else 0f
                val bh = lm.height + (ls?.height ?: 0) + gap + dp(16f)
                val top = cy + (if (octo) r * 1.3f else r) + dp(10f)
                paint.style = Paint.Style.FILL
                paint.color = 0x141A1E or ((0xC0 * a).toInt().coerceIn(0, 255) shl 24)
                c.drawRoundRect((w - bw) / 2f, top, (w + bw) / 2f, top + bh, min(bh / 2f, dp(22f)), min(bh / 2f, dp(22f)), paint)
                c.save()
                c.translate((w - maxW) / 2f, top + dp(8f))
                lm.draw(c)
                if (ls != null) {
                    c.translate(0f, lm.height + gap)
                    ls.draw(c)
                }
                c.restore()
            }
        }
        if (demo) {
            lab.textSize = sp(12f)
            lab.color = if (octo) 0xFF5C6870.toInt() else 0xFF7F9BB8.toInt()
            lab.textAlign = Paint.Align.CENTER
            val nm = listOf("Waiting", "Listening", "Thinking", "Speaking")[previewState]
            c.drawText("$nm  (tap to change)", w / 2f, h - dp(12f), lab)
        }
        postInvalidateOnAnimation()
    }
}

/** What to say to bring the eye up or send it away. */
object Eye {
    private val summon = setOf(
        "i summon you", "summon you", "eyes on me", "ride the wave", "arise", "wave",
        "i someone you", "someone you", "i summoned you", "summoned you", "i salmon you", "salmon you",
        "i summon u", "summon u", "i some one you", "some one you", "i sum in you", "i summing you",
        "i summon ya", "i summoning you", "i summon", "summon",
        "show your eye", "show me your eye", "open your eye", "open your eyes", "show your eyes", "show me your eyes"
    )
    private val close = setOf(
        "close", "close eye", "close the eye", "close your eye", "close your eyes", "eyes off", "go away",
        "dismiss", "thats all", "that's all", "stand down", "you may go", "go back", "never mind eye"
    )

    /** True if the sentence was about the eye, so nothing else should run. */
    fun handle(t: String): Boolean {
        val s = t.trim()
        val h = Hands.inst
        if (h != null && h.eyeOpen() && s in close) {
            h.eyeClose()
            return true
        }
        val lo = s.lowercase().replace(Regex("[^a-z ]"), " ").replace(Regex("\\s+"), " ").trim()
        // the mic often hears "summon" as "someone"/"salmon": "(poseidon) i <sounds like summon> you" counts too
        val sounds = Regex("^(.* )?i (summon|summoned|summoning|someone|some one|salmon|sum in|summing|sermon) (you|u|ya)$")
        if (lo in summon || s in summon || lo.endsWith(" i summon you") || sounds.containsMatchIn(lo)) {
            if (h == null) {
                Fx.words("Switch on Wave Hands", "The eye needs it (Setup, step with Accessibility).", 2600)
                return true
            }
            h.eyeSummon()
            Buddy.addLog(t, "Summoned the eye", true)
            return true
        }
        return false
    }
}

/** All the eye's settings on their own page. */
@Composable
fun EyePage(back: () -> Unit, closer: () -> Unit = {}, play: () -> Unit = {}) {
    fun pct(v: Float) = (v * 100).toInt().toString() + "%"
    val octo = Store.s("eyestyle", "octopus") != "jarvis"
    Page {
        Header("Eye", "Wave's face on the screen", back)

        Tx("Show", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
        Glass {
            ToggleRow("Use the eye", "The eye replaces the floating words, in Wave and over other apps.", Store.b("eyeon", true)) { Store.put("eyeon", it) }
            ToggleRow("Slow fade", "It fades in and out gently.", Store.b("eyeslow", false)) { Store.put("eyeslow", it) }
            Spacer(Modifier.height(4.dp))
            Tx("Look", 13)
            Spacer(Modifier.height(6.dp))
            Seg(listOf("Octopus", "Jarvis"), if (octo) 0 else 1) { Store.put("eyestyle", if (it == 0) "octopus" else "jarvis") }
            Spacer(Modifier.height(8.dp))
            AndroidView(
                factory = { EyeBox(it, preview = true) },
                update = { },
                onRelease = { it.drop() },
                modifier = Modifier.fillMaxWidth().height(280.dp)
            )
            Tx(if (octo) "Poseidon OC-8, the robot octopus. Tap the picture to see it wait, listen, think and speak."
                else "The original Jarvis eye. Tap the picture to see it wait, listen, think and speak.", 12, Mute, FontWeight.Normal)
            if (octo) {
                Spacer(Modifier.height(8.dp))
                Btn("Take a closer look", filled = true, onClick = closer)
            }
        }

        if (octo) {
            Tx("Octopus", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
            Glass {
                Tx("How it arrives when summoned", 13)
                Spacer(Modifier.height(6.dp))
                val asm = listOf("slow", "snappy", "fade")
                Seg(listOf("Slow build", "Snappy", "Fade in"), asm.indexOf(Store.s("octoasm", "slow")).coerceAtLeast(0)) { Store.put("octoasm", asm[it]) }
                Spacer(Modifier.height(10.dp))
                Tx("How it leaves", 13)
                Spacer(Modifier.height(6.dp))
                val ex = listOf("fade", "disassemble")
                Seg(listOf("Fade out", "Come apart"), ex.indexOf(Store.s("octoexit", "fade")).coerceAtLeast(0)) { Store.put("octoexit", ex[it]) }
                Spacer(Modifier.height(6.dp))
                SliderRow("Waviness", Store.f("octowavy", 1f), 0f..2f, pct(Store.f("octowavy", 1f))) { Store.put("octowavy", it) }
                SliderRow("Swim speed", Store.f("octoswim", 1f), 0.3f..2.2f, "%.1fx".format(Locale.US, Store.f("octoswim", 1f))) { Store.put("octoswim", it) }
                SliderRow("Roaming", Store.f("octoroam", 1f), 0f..2f, if (Store.f("octoroam", 1f) < 0.05f) "Stays put" else pct(Store.f("octoroam", 1f))) { Store.put("octoroam", it) }
                InfoLine("How far it swims around. It hovers and breathes, glides, jets off with its arms trailing, then opens its arms to slow down and looks at you.")
                SliderRow("Glow", Store.f("octoglow", 1f), 0f..1.6f, pct(Store.f("octoglow", 1f))) { Store.put("octoglow", it) }
                InfoLine("How bright and shiny it is. 100% is the original look. Lower is calmer and more matte; above 100% the orange starts to glow.")
                Tx("Shell", 13)
                Spacer(Modifier.height(6.dp))
                Seg(listOf("White", "Graphite"), if (Store.s("octoshell", "white") == "graphite") 1 else 0) {
                    Store.put("octoshell", if (it == 1) "graphite" else "white")
                    Hands.inst?.refresh()
                }
                Spacer(Modifier.height(6.dp))
                Tx("When it is summoned, tap an arm to poke it or tap the head to startle it. Tap beside it to send it away.", 12, Mute, FontWeight.Normal)
                Spacer(Modifier.height(8.dp))
                Btn("Play with me", filled = true, onClick = play)
                Tx("Or long-press the octopus on the home screen.", 12, Mute, FontWeight.Normal)
            }
        }

        Tx("Shape and size", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
        Glass {
            SliderRow("Size", Store.f("eyesize", 0.42f), 0.25f..0.8f, pct(Store.f("eyesize", 0.42f))) { Store.put("eyesize", it) }
            SliderRow("Height on screen", Store.f("eyey", 0.25f), 0.08f..0.8f, pct(Store.f("eyey", 0.25f))) { Store.put("eyey", it) }
            if (!octo) {
                SliderRow("Speed", Store.f("eyespeed", 1f), 0.4f..2.5f, "%.1fx".format(Locale.US, Store.f("eyespeed", 1f))) { Store.put("eyespeed", it) }
                ColourPick("Eye colour", "Normal is Jarvis blue", "c_eye", androidx.compose.ui.graphics.Color(0xFF3FD0FF))
                ToggleRow("Blink", "Now and then.", Store.b("eyeblink", true)) { Store.put("eyeblink", it) }
                ToggleRow("Look around", "The pupil drifts when I'm just waiting.", Store.b("eyewander", true)) { Store.put("eyewander", it) }
            }
        }

        Tx("Mic button", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
        Glass {
            ToggleRow("Poseidon eye on the mic button", "The round button on the screen edge becomes the PE-1 eye. Off brings back the flat button.", Store.b("fab3d", true)) {
                Store.put("fab3d", it)
                Hands.inst?.refresh()
            }
            ToggleRow("Open up while listening", "The eye pulls partly apart and grows while it hears you, and closes again after.", Store.b("fabopen", true)) {
                Store.put("fabopen", it)
                Hands.inst?.refresh()
            }
            SliderRow("Size while listening", Store.f("fabgrow", 1.6f), 1f..2.2f, pct(Store.f("fabgrow", 1.6f))) { Store.put("fabgrow", it) }
            SliderRow("How far it comes apart", Store.f("fabapart", 0.85f), 0.2f..1f, pct(Store.f("fabapart", 0.85f))) { Store.put("fabapart", it); Hands.inst?.setFabMode() }
            SliderRow("Turning while apart", Store.f("fabspin", 1f), 0f..2f, if (Store.f("fabspin", 1f) < 0.05f) "Still" else pct(Store.f("fabspin", 1f))) { Store.put("fabspin", it); Hands.inst?.setFabMode() }
            InfoLine("While it hears you, the eye comes apart and slowly turns. When you finish it turns back to face you and clicks together.")
            SliderRow("Glow", Store.f("fabglow", 1f), 0f..1.6f, pct(Store.f("fabglow", 1f))) { Store.put("fabglow", it); Hands.inst?.setFabMode() }
            Tx("The iris shuts when the mic is closed (walkie-talkie or resting) and opens when I can hear you.", 12, Mute, FontWeight.Normal)
        }

        Tx("Mic eye's character", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
        Glass {
            ToggleRow("Idle tricks", "Now and then, when you're not talking to it.", Store.b("fabtricks", true)) { Store.put("fabtricks", it); Hands.inst?.setFabMode() }
            InfoLine("Rare and random: it comes apart and clicks back, spins its focus ring up, double-blinks and looks round, does a full roll, or pops its glass off and polishes it. Never while you're talking.")
            if (Store.b("fabtricks", true)) {
                SliderRow("How often", Store.f("fabtrickoften", 1f), 0.3f..3f, when {
                    Store.f("fabtrickoften", 1f) < 0.7f -> "Rarely"
                    Store.f("fabtrickoften", 1f) < 1.6f -> "Sometimes"
                    else -> "Often"
                }) { Store.put("fabtrickoften", it); Hands.inst?.setFabMode() }
            }
            ToggleRow("Moods", "Tired on low battery, dozing on the charger.", Store.b("fabmoods", true)) { Store.put("fabmoods", it); Hands.inst?.setFabMode() }
            ToggleRow("Peek from the edge", "Left alone, it hides off the screen edge and peeks back.", Store.b("fabpeek", true)) { Store.put("fabpeek", it); Hands.inst?.setFabMode() }
            if (Store.b("fabpeek", true)) {
                SliderRow("Hides after", Store.i("fabpeekmin", 4).toFloat(), 1f..20f, Store.i("fabpeekmin", 4).toString() + " min") { Store.put("fabpeekmin", it.toInt()); Hands.inst?.setFabMode() }
                InfoLine("Touch it, talk to it or say the wake word and it comes straight back out.")
            }
        }

        Tx("Words under the eye", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
        Glass {
            ToggleRow("Small caption", "One short line for things you need to read, like \"Say yes to confirm\".", Store.b("eyecap", true)) { Store.put("eyecap", it) }
            SliderRow("Caption size", Store.i("eyecapsize", 15).toFloat(), 10f..24f, Store.i("eyecapsize", 15).toString()) { Store.put("eyecapsize", it.toInt()) }
            Tx("The caption colour is \"Wave's reply\" in Look and feel.", 12, Mute, FontWeight.Normal)
        }

        Tx("Summon", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
        Glass {
            Tx("Say \"Poseidon, I summon you\" or \"Hey Wave, eyes on me\". The eye comes up big, with no captions, and I listen without the wake word. Say \"close\", or tap beside it.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            SliderRow("How long it stays", Store.i("eyestay", 20).toFloat(), 5f..60f, Store.i("eyestay", 20).toString() + " s") { Store.put("eyestay", it.toInt()) }
            SliderRow("Summon size", Store.f("eyesumsize", 0.9f), 0.5f..1.0f, pct(Store.f("eyesumsize", 0.9f))) { Store.put("eyesumsize", it) }
            SliderRow("Dim the screen behind", Store.f("eyedim", 0.8f), 0f..1f, pct(Store.f("eyedim", 0.8f))) { Store.put("eyedim", it) }
            ToggleRow("Tap to close", "Tap the eye (or beside the octopus) to send it away.", Store.b("eyetap", true)) { Store.put("eyetap", it) }
        }

        Tx("Try it", 13, Coral, FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
        Glass {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Preview") { Hands.inst?.eyeWords("Hello " + Store.s("callme", "BreadWinner"), "This is my eye", 2600) }
                Btn("Summon", filled = true) { Hands.inst?.eyeSummon() }
            }
            if (Hands.inst == null) Tx("The eye needs Wave Hands (Accessibility) switched on. See Setup.", 12, Mute, FontWeight.Normal)
        }
        Spacer(Modifier.height(8.dp))
    }
}
