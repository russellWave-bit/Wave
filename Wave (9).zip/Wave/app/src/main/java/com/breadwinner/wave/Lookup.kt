package com.breadwinner.wave

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

class AppRow(val label: String, val pkg: String)
class Person(val name: String, val numbers: List<String>)

/** "When I say mum, I mean Mum Mobile." Your own word list, checked before anything else. */
object Vocab {
    fun alias(said: String): String {
        val c = Norm.clean(said)
        for ((a, b) in Store.vocab) if (Norm.clean(a) == c) return b
        return said
    }
}

object Apps {
    private var cache: List<AppRow> = emptyList()
    private var at = 0L

    fun all(): List<AppRow> {
        val now = System.currentTimeMillis()
        if (cache.isEmpty() || now - at > 60000) {
            val ctx = Store.app
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val out = ArrayList<AppRow>()
            try {
                for (ri in pm.queryIntentActivities(i, 0)) {
                    val p = ri.activityInfo.packageName
                    if (!seen.add(p)) continue
                    out.add(AppRow(ri.loadLabel(pm).toString(), p))
                }
            } catch (e: Exception) {
            }
            cache = out
            at = now
        }
        return cache
    }

    /**
     * The speech engine often splits an app name into ordinary words: "WhatsApp" comes out as "what a",
     * "what app" or just "what". These are joined back before looking for the app.
     */
    private val heardAs = mapOf(
        "whatsapp" to listOf(
            "what", "what a", "what app", "what a app", "whats a", "what's a", "whats a app", "what's a app", "whats", "what's",
            "what up", "whats up", "what's up", "wassup", "what sup", "what sap", "watsap", "wats app", "watts app", "what s app",
            "whats app", "what's app", "what the app", "what's that", "what are", "what are app", "water app", "what's ap", "whatsap"
        ),
        "facebook" to listOf("face book", "facebooks", "face look", "faith book"),
        "youtube" to listOf("you tube", "u tube", "you two", "youtube app", "you tub"),
        "instagram" to listOf("insta", "insta gram", "instagrams"),
        "tiktok" to listOf("tik tok", "tick tock", "tic toc", "tick tok"),
        "gmail" to listOf("g mail", "gee mail", "jimmy l", "g male"),
        "telegram" to listOf("tele gram", "tell a gram"),
        "chrome" to listOf("crome", "chrome browser", "google chrome"),
        "spotify" to listOf("spot if i", "spot a fly", "spotty fy"),
        "snapchat" to listOf("snap chat", "snap"),
        "calculator" to listOf("calc", "calculate"),
        "camera" to listOf("camra", "the camera"),
    )

    fun fixName(said: String): String {
        val c = Norm.clean(said)
        for ((name, ways) in heardAs) if (c in ways) return name
        return said
    }

    /** A rough "sounds like" key: the consonant skeleton, so "what a app" and "whatsapp" come out the same. */
    private fun key(s: String): String {
        var t = s.lowercase().filter { it in 'a'..'z' }
        if (t.isEmpty()) return ""
        t = t.replace("wh", "w").replace("ph", "f").replace("ck", "k").replace("q", "k").replace("z", "s").replace("ts", "t").replace("s", "")
        val sb = StringBuilder()
        sb.append(t[0])
        for (i in 1 until t.length) {
            val ch = t[i]
            if (ch in "aeiouy") continue
            if (sb.last() == ch) continue
            sb.append(ch)
        }
        return sb.toString()
    }

    /** Best app for what you said, with how sure we are (0 to 1). */
    fun find(said: String): Pair<AppRow, Float>? {
        var q = fixName(Vocab.alias(said))
        // "open what a app": the word "app" at the end is just talk
        val words = Norm.clean(q).split(" ")
        if (words.size > 1 && words.last() == "app") q = fixName(words.dropLast(1).joinToString(" "))
        val qk = key(q)
        var best: AppRow? = null
        var bs = 0f
        for (a in all()) {
            var s = Norm.nameScore(q, a.label)
            if (a.pkg.equals(q.trim(), true)) s = 1f
            // sounds the same, or sounds like the start of it
            val lk = key(a.label)
            if (qk.length >= 2 && lk.isNotEmpty() && qk[0] == lk[0]) {
                if (qk == lk) s = maxOf(s, 0.88f)
                else if (lk.startsWith(qk) && qk.length >= 3) s = maxOf(s, 0.78f)
            }
            s += 0.02f * Norm.sim(Norm.clean(q), Norm.clean(a.label))
            if (s > bs || (s == bs && best != null && a.label.length < best.label.length)) { bs = s; best = a }
        }
        val b = best ?: return null
        return b to bs.coerceAtMost(1f)
    }
}

object Contacts {
    private var cache: List<Person> = emptyList()
    private var at = 0L

    fun granted(): Boolean =
        ContextCompat.checkSelfPermission(Store.app, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun all(): List<Person> {
        if (!granted()) return emptyList()
        val now = System.currentTimeMillis()
        if (cache.isNotEmpty() && now - at < 60000) return cache
        val map = LinkedHashMap<String, MutableList<String>>()
        try {
            val cur = Store.app.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )
            cur?.use {
                while (it.moveToNext()) {
                    val n = it.getString(0) ?: continue
                    val num = it.getString(1) ?: continue
                    map.getOrPut(n) { ArrayList() }.add(num)
                }
            }
        } catch (e: Exception) {
        }
        cache = map.map { Person(it.key, it.value) }
        at = now
        return cache
    }

    fun find(said: String): Pair<Person, Float>? {
        val q = Vocab.alias(said)
        var best: Person? = null
        var bs = 0f
        for (p in all()) {
            val s = Norm.nameScore(q, p.name)
            if (s > bs) { bs = s; best = p }
        }
        val b = best ?: return null
        return b to bs
    }

    /** International digits for WhatsApp, using your country code for numbers that start with 0. */
    fun waNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) d = Store.country + d.substring(1)
        return d
    }
}
