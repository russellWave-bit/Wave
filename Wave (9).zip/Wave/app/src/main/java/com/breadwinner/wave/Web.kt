package com.breadwinner.wave

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * One see-through 3D page from the app's own files (no internet): the octopus or the mic-button eye.
 * Anything sent before the page has loaded waits in a short queue.
 */
@SuppressLint("SetJavaScriptEnabled")
class Stage3D(ctx: Context, page: String, private val onMiss: (() -> Unit)? = null, private val onLong: (() -> Unit)? = null) {
    var web: WebView? = null
        private set
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayList<String>()

    init {
        try {
            val w = WebView(ctx)
            w.setBackgroundColor(Color.TRANSPARENT)
            w.settings.javaScriptEnabled = true
            w.settings.mediaPlaybackRequiresUserGesture = true
            w.settings.domStorageEnabled = true   // the Build game keeps your best times
            w.isVerticalScrollBarEnabled = false
            w.isHorizontalScrollBarEnabled = false
            w.overScrollMode = View.OVER_SCROLL_NEVER
            w.addJavascriptInterface(Bridge(), "WaveHost")
            w.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) { markReady() }
            }
            w.loadUrl("file:///android_asset/poseidon/$page")
            web = w
        } catch (e: Throwable) {
            web = null
        }
    }

    inner class Bridge {
        @JavascriptInterface fun ready() { main.post { markReady() } }
        @JavascriptInterface fun miss() { main.post { onMiss?.invoke() } }
        @JavascriptInterface fun longPress() { main.post { onLong?.invoke() } }
    }

    private fun markReady() {
        if (ready) return
        ready = true
        for (code in queue) run(code)
        queue.clear()
    }

    fun js(code: String) {
        if (web == null) return
        if (!ready) { if (queue.size < 40) queue.add(code); return }
        run(code)
    }

    private fun run(code: String) {
        try { web?.evaluateJavascript(code, null) } catch (e: Throwable) { }
    }

    fun destroy() {
        try { web?.destroy() } catch (e: Throwable) { }
        web = null
    }
}

/**
 * Holds the eye. The flat Jarvis eye is drawn by EyeView; the octopus is a 3D page laid over it.
 * EyeView stays in charge of when the eye shows, how big it is and where it sits.
 */
class EyeBox(ctx: Context, preview: Boolean = false, live: Boolean = false, private val onLong: (() -> Unit)? = null) : FrameLayout(ctx) {
    val eye = EyeView(ctx)
    private var stage: Stage3D? = null
    private var failed = false
    private var shown = false
    private var shownBig = false
    private var lastMood = -1
    private var lastLevelAt = 0L
    private var lastSet = ""
    private var tick = 0

    companion object {
        /** True while the octopus on Wave's own home screen is visible, so the floating one doesn't double up. */
        @Volatile var liveUp = false
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (eye.live) liveUp = visibility == View.VISIBLE
    }

    override fun onDetachedFromWindow() {
        if (eye.live) liveUp = false
        super.onDetachedFromWindow()
    }

    init {
        eye.preview = preview || live
        eye.live = live
        eye.host = this
        addView(eye, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    /** True if the 3D octopus can be shown on this phone. Loads it the first time. */
    fun canShow(): Boolean {
        if (failed) return false
        if (stage == null) {
            val s = Stage3D(context, "octopus.html#embed", { onMiss() }, onLong)
            val w = s.web
            if (w == null) { failed = true; return false }
            w.visibility = View.INVISIBLE
            addView(w, LayoutParams(64, 64, Gravity.TOP or Gravity.START))
            stage = s
            shown = false
            lastMood = -1
            lastSet = ""
        }
        return true
    }

    /** Load the octopus early, so the first summon doesn't wait. */
    fun warm() { canShow() }

    private fun onMiss() {
        if (eye.summoned && Store.b("eyetap", true)) Hands.inst?.eyeClose()
    }

    /** Called by EyeView on every frame while the octopus is the chosen look. */
    fun frame(cx: Float, cy: Float, r: Float, alpha: Float, want: Boolean, big: Boolean, mood: Int, level: Float) {
        val s = stage ?: return
        val w = s.web ?: return
        val fill = eye.preview
        val side = if (fill) min(width, height) else min(min(width, height).toFloat(), r * 2.7f).toInt()
        if (side < 8) return
        val lp = w.layoutParams as LayoutParams
        // summoned: the whole screen, so parts can fly in from every edge without being clipped
        val full = eye.live || (big && !fill)
        val bw = if (full) width else side
        val bh = if (full) height else side
        val left = (cx - bw / 2f).toInt().coerceIn(0, max(0, width - bw))
        val top = (cy - bh / 2f).toInt().coerceIn(0, max(0, height - bh))
        if (lp.width != bw || lp.height != bh || lp.leftMargin != left || lp.topMargin != top) {
            lp.width = bw; lp.height = bh; lp.leftMargin = left; lp.topMargin = top
            w.layoutParams = lp
        }
        if (w.visibility != View.VISIBLE) w.visibility = View.VISIBLE
        w.alpha = alpha.coerceIn(0f, 1f)

        if (tick++ % 30 == 0) {
            val roam = if (eye.preview && !eye.live) 0f else Store.f("octoroam", 1f)
            val key = "%.2f|%.2f|%s|%.2f|%.2f".format(Locale.US, Store.f("octowavy", 1f), Store.f("octoswim", 1f), Store.s("octoshell", "white"), Store.f("octoglow", 1f), roam)
            if (key != lastSet) {
                lastSet = key
                s.js("octopus.set({waviness:%.2f,speed:%.2f,shell:'%s',glow:%.2f,roam:%.2f})".format(Locale.US, Store.f("octowavy", 1f), Store.f("octoswim", 1f),
                    if (Store.s("octoshell", "white") == "graphite") "graphite" else "white", Store.f("octoglow", 1f), roam))
            }
        }
        if (want != shown) {
            shown = want
            if (want) {
                shownBig = big
                val how = if (big || eye.live) safe(Store.s("octoasm", "slow"), "slow", "snappy", "fade") else "fade"
                s.js("octopus.summon({assembly:'$how',fast:${!big}})")
            } else {
                val how = if (shownBig) safe(Store.s("octoexit", "fade"), "fade", "disassemble") else "fade"
                s.js("octopus.dismiss({exit:'$how',fast:${!shownBig}})")
            }
        }
        if (mood != lastMood) {
            lastMood = mood
            s.js("octopus.mood($mood)")
        }
        if (mood == 1) {
            val now = System.currentTimeMillis()
            if (now - lastLevelAt > 100) {
                lastLevelAt = now
                s.js("octopus.level(%.2f)".format(Locale.US, level.coerceIn(0f, 1f)))
            }
        }
    }

    private fun safe(v: String, vararg ok: String): String = if (v in ok) v else ok[0]

    /** The flat eye is showing instead: put the octopus away. */
    fun hideOcto() {
        val s = stage ?: return
        val w = s.web ?: return
        if (w.visibility == View.VISIBLE) w.visibility = View.INVISIBLE
        if (shown) { shown = false; s.js("octopus.dismiss({exit:'fade',fast:true})") }
    }

    /** The eye has left the screen: the octopus goes quiet until next time. */
    fun rest() {
        if (shown) { shown = false; stage?.js("octopus.dismiss({exit:'fade',fast:true})") }
        lastMood = -1
    }

    fun poke() { stage?.js("octopus.poke()") }

    /** Free the 3D page completely. */
    fun drop() {
        val s = stage ?: return
        try { s.web?.let { removeView(it) } } catch (e: Throwable) { }
        s.destroy()
        stage = null
        shown = false
    }

    // In the settings preview a tap changes what the eye is doing, so the page underneath never sees it.
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = eye.preview && !eye.live

    override fun onTouchEvent(ev: MotionEvent): Boolean = if (eye.preview && !eye.live) eye.onTouchEvent(ev) else super.onTouchEvent(ev)
}

/** The octopus up close: turn it, poke it, take it apart and read what each part is. */
@Composable
fun OctoPage(back: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 14.dp)) {
        Header("Poseidon OC-8", "Turn it, poke it, take it apart", back)
        AndroidView(
            factory = { c ->
                val s = Stage3D(c, "octopus.html")
                val holder = FrameLayout(c)
                s.web?.let { holder.addView(it, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)) }
                holder.tag = s
                holder
            },
            onRelease = { (it.tag as? Stage3D)?.destroy() },
            modifier = Modifier.fillMaxWidth().weight(1f).padding(bottom = 8.dp)
        )
    }
}

/** Play with me: long-press the octopus on the home screen. Play with it, or scatter it and build it back against the clock. */
@Composable
fun PlayPage(back: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 14.dp)) {
        Header("Play with me", "Play with it, or build it back", back)
        AndroidView(
            factory = { c ->
                val s = Stage3D(c, "octopus.html#play")
                val holder = FrameLayout(c)
                s.web?.let { holder.addView(it, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)) }
                holder.tag = s
                val sh = if (Store.s("octoshell", "white") == "graphite") "graphite" else "white"
                s.js("octopus.set({shell:'%s',glow:%.2f,roam:%.2f})".format(Locale.US, sh, Store.f("octoglow", 1f), Store.f("octoroam", 1f).coerceAtLeast(0.6f)))
                holder
            },
            onRelease = { (it.tag as? Stage3D)?.destroy() },
            modifier = Modifier.fillMaxWidth().weight(1f).padding(bottom = 8.dp)
        )
    }
}
